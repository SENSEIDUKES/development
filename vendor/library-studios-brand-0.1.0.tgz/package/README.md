# Novel Expanded branding

`@library-studios/brand` owns the reusable **NovelExpandedLogo** and its artwork.
MP Studio is the first consumer. Other studios can adopt the public exports without
importing an app, copying CSS, adding Tailwind, or upgrading their existing UI adapter.
This is a browser React/Vite component, with React 19 as its only runtime peer.

```tsx
import { NovelExpandedLogo } from '@library-studios/brand';
import '@library-studios/brand/styles.css';

<NovelExpandedLogo size="md" theme={isDark ? 'dark' : 'light'} />
```

Add `"@library-studios/brand": "workspace:*"` to the consuming app. Import the
stylesheet once. The host owns placement, theme selection and navigation.

## Sizing and composition

| Prop | Behavior |
| --- | --- |
| `size` | Plate height: `sm` 32px, `md` 40px, `lg` 56px, `xl` 80px, or a positive number. Defaults to 40px through CSS. |
| `theme` | `light` or `dark`; defaults to `dark`. Independent of the host's theme framework. |
| `animated` | Defaults to `true`. Set to `false` for a static spectrum. Reduced-motion preferences always take precedence. |
| `alt` | Defaults to `Novel Expanded`. Use `""` when a surrounding link already names the destination. |
| `imageSizes` | Optional responsive image display width; useful when CSS controls the logo's size. |
| `className`, `style`, `ref`, span attributes | Passed through to the outer span. No internal interactive controls or state. |

Sizes 24–256px are browser-checked at pixel ratio 3. Prefer at least 32px when the
wordmark needs to be read. Width follows the artwork and padding; the image keeps
its aspect ratio. The plate reserves its dimensions before the image loads.
The glow needs a little space outside the plate; avoid clipping it in the host.
As with other fixed-size content, use `minmax(0, 1fr)` for a grid track that should
shrink inside a narrow container.

For responsive CSS, omit `size` and set `--ne-logo-height` on the host class:

```css
.studio-logo { --ne-logo-height: clamp(32px, 4vw, 56px); }
```

An explicit `size` sets the variable inline. MP keeps its existing 36px / 40px
header sizing and 24px / 28px artwork sizing in its own Header.css.

```tsx
<a href={homeUrl} aria-label="Novel Expanded home">
  <NovelExpandedLogo alt="" theme="dark" />
</a>
```

The host supplies the link's focus treatment and touch target. The logo alone is
an image, so it does not introduce a redundant tab stop. The two glow layers are
hidden from assistive technology and cannot intercept pointer events.

## Artwork and performance

The component bundles transparent 320, 640 and 1280px WebP assets. Vite emits
cacheable URLs; `srcset` selects the appropriate file for the display width and
pixel ratio. It does not rely on an app's public folder or a remote image host.
The original PNG remains in MP for its favicon and existing OpenAPI docs.

The spectrum retains Development's cyan, violet and gold palette and 18-second
timing. Oversized gradient layers move with CSS transforms instead of animating
background position. There are no timers, observers, state updates, new runtime
dependencies, or persistent `will-change` hints. Static/reduced-motion instances
have no running animation. Keep repeated decorative lists static when movement
does not help the page.

[Audit and validation](../../docs/NOVEL-EXPANDED-LOGO.md) records measured results
and the source artwork. Run `npm test --workspace packages/brand`; root
`npm run verify` includes those tests. With MP's development server running,
the development-only gallery is at
`/@fs/<absolute repository path>/packages/brand/fixtures/preview.html`.
It is not an MP production entry or a public studio page.

## History

- **2026-10-23:** Extracted the approved MP corner logo into shared branding;
  added size/theme/static controls, local responsive artwork, compositor animation,
  accessibility checks, a size gallery and a performance audit. MP is the first consumer.
