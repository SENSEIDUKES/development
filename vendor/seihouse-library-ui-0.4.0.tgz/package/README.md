# Celestial Library UI

The UI monorepo owns the canonical Celestial Library presentation layer at
`@seihouse/library-ui`. Its panels, cards, controls, navigation, glyphs and particles
use the existing `sen` experience. Routing, authentication, storage, generation
and audio playback remain host responsibilities.

This phase provides a private **`@seihouse/library-ui@0.4.0`** artifact with two exports:

| Export                            | Built file                          | Purpose                                                                          |
| --------------------------------- | ----------------------------------- | -------------------------------------------------------------------------------- |
| `@seihouse/library-ui`            | `dist/ui/index.js` and `index.d.ts` | Components and their public types                                                |
| `@seihouse/library-ui/styles.css` | `dist/styles.css`                   | Shared UI tokens/source registration, SEN utility vocabulary, glass/spectral CSS |

The dependency direction is `@seihouse/library-ui` → `@seihouse/ui@^0.4.0`. The universal
package retains the existing `sen` experience and has no dependency on this
product package or its Library skin. The Library UI package has
no application imports. Its peer dependencies are React 19, React DOM 19, Lucide
and the universal UI package. It adds no animation engine.

The portable `@seihouse/sen` narrative engine and first-party `@seihouse/library` features remain owned by development. This repository produces no SEN artifact. Library may depend on SEN and Library UI; SEN must not depend on either Library package.

## Consume the built artifact

Build with `pnpm build:package`, then pack both packages, in dependency order:

```sh
npm pack ./packages/seihouse-ui --pack-destination ./output
npm pack ./packages/seihouse-library-ui --pack-destination ./output
```

Install both tarballs in a host with the declared peers. The application uses
Tailwind CSS v4, matching the universal UI stylesheet contract. Import CSS once:

```css
@import "tailwindcss";
@import "@seihouse/library-ui/styles.css";
```

```tsx
import { LibraryPanel, LibraryTextBox, ManifestButton } from "@seihouse/library-ui";

export function WorldForm() {
  return (
    <section data-experience="sen" data-theme="dark">
      <LibraryPanel>
        <LibraryTextBox label="World name" defaultValue="Astral realm" />
        <ManifestButton type="submit">Manifest World Blueprint</ManifestButton>
      </LibraryPanel>
    </section>
  );
}
```

CSS is explicitly imported rather than evaluated by the JavaScript entry, so
Node SSR and native ESM can load the package. The CSS registers shipped JS with
Tailwind; no workspace source alias or host `node_modules` scan is needed.
Importing this CSS alone without a Tailwind v4 build does not generate utilities.

Font families retain the reference: Rubik, Noto Serif, Alegreya and Alegreya SC.
The host supplies these fonts under its font-loading policy; serif/system
fallbacks remain available. The package performs no remote font requests.
SEN utility colors and font names are prefixed `sen-` to avoid overriding the
universal or host Tailwind theme. Existing `--library-card-*`,
`--celestial-accent` and spectral/glass class hooks are retained.

## Public components

- `LibraryPanel`: `default`, `callout`, `footer`; polymorphic section container.
- `LibraryCard`: static, button or link cards; `default` and `callout` skins,
  accent colors, padding and convenience slots. Compound exports:
  `LibraryCardMedia`, `LibraryCardContent`, `LibraryCardHeader`, `LibraryCardTitle`,
  `LibraryCardDescription`, `LibraryCardBody`, `LibraryCardMetadata`,
  `LibraryCardActions`, `LibraryCardFooter`.
- `LibraryButton`: `primary`, `secondary`, `ghost`, `danger`; `sm`, `md`, `lg`,
  `icon`; refs, icon slots, `iconSize`, custom loading indicator and native props.
- `ManifestButton`: spectral creation action with the same behavior and sizing.
- `LibraryTextBox`, `LibraryTextArea`: glass fields, labels/helper/error IDs,
  controlled string callbacks, uncontrolled native values, icons, overlays,
  compact mode, required/disabled state and textarea character count.
- `LibraryHeaderBadge`: title, subtitle, optional emblem and home link; use
  `mode="app-header"` for inline, non-heading composition inside `SEIAppHeader`.
- `LibraryNavigationDrawer`, `LibraryNavigationDrawerPanel`: controlled modal
  and standalone sidebar, grouped destinations, profile and close labels.
- `LibraryBottomNavigation`: presentational destinations, selection callbacks,
  optional visually hidden labels, safe-area dock.
- `LibraryDragonCycleIcon`, `LibrarySoundGlyph`: specialized cycle and sound
  vocabulary, decorative/informative accessibility contracts.
- `ParticleEffect`: accent-derived celestial particles with embedded glyphs,
  foreground calm zones, speed and dispersion controls; no host asset URLs.

All reference public `Library*`, `ManifestButton` and `ParticleEffect` prop types
are exported with their existing names. Raw shared primitives and `cn` come from
`@seihouse/ui`; they are not duplicated or re-exported by Library UI.

## Independent verification

`/sen` in the workbench shows the complete set. Each of the 12 families has its
own catalog entry and Storybook story under `Library UI`. Both preview apps
resolve Library UI's built exports. Run `pnpm build:package` again after changing Library UI
source before using an already running preview server.

```sh
pnpm typecheck
pnpm test:unit
pnpm test:package
pnpm lint
pnpm build
pnpm build:storybook
pnpm exec playwright test test/accessibility/sen-library.spec.ts
```

The package contract installs fresh tarballs outside the workspace, verifies
runtime exports, TypeScript contracts, reproducibility, and compiles the shipped
CSS with Tailwind. Browser checks cover desktop/mobile layout, fields, keyboard
activation, modal focus/dismissal, axe accessibility and changing motion settings.
See [the Prompt 3 migration map](../../docs/library-ui-migration.md) for import mapping
and intentional differences.

## Elemental title

`LibraryElementalTitle` renders semantic, readable lettering with optional fire,
lightning, frost, celestial, or void illumination. It adds no badge surface.
Import `@seihouse/library-ui/styles.css` once in the host alongside the component:

```tsx
import { LibraryElementalTitle } from "@seihouse/library-ui";

<LibraryElementalTitle as="h2" element="fire" intensity="active" shadow="outlined">
  {readerName}
</LibraryElementalTitle>;
```

String children are escaped by React. `as` supports `span` (default), `p`, and
`h1`–`h6`; choose a heading level appropriate to the document. Native attributes,
events, styles, and a DOM ref are forwarded. `element="none"` (default) preserves
the original plain text contract. Font family, weight, line height and size inherit
from the host profile. Consumer classes override the low-specificity defaults.

| Prop        | Values                                                    | Default   |
| ----------- | --------------------------------------------------------- | --------- |
| `element`   | `none`, `fire`, `lightning`, `frost`, `celestial`, `void` | `none`    |
| `intensity` | `subtle`, `active`, `legendary`                           | `active`  |
| `motion`    | `ambient`, `hover`, `burst`                               | `ambient` |
| `size`      | `inherit`, `sm`, `md`, `lg`, `xl` (responsive)            | `inherit` |
| `shadow`    | `none`, `soft`, `outlined`                                | `soft`    |

Ambient motion runs while visible. Hover motion also responds to keyboard focus
on a containing button or link. Burst plays once (1.6 seconds) on pointer entry,
press, or focus; repeated input during the burst does not restart it. The title
never adds a tab stop or intercepts an action. The host owns interactive semantics.

Real text supplies the accessible name and layout. Decorative copies are hidden
from assistive technology and ignore pointer input. Fire has a moving letter fill
and scattered embers; lightning uses small disconnected arcs and restrained local
flicker. Particles are anchored to at most eight measured glyphs (four visible on
mobile); the real text is never split, preserving shaping and wrapping. No Canvas,
video, animation dependency, or font request is added.

Effects pause offscreen and when the document is hidden. Reduced motion keeps static
illuminated lettering without particles; forced colors use native readable text.
Before hydration or without browser observers, text is still readable. Palettes
follow the host's `color-scheme` via the UI `data-theme` / `.sh-theme-*` scopes.
Long names wrap without truncation. Animation and decoration do not change geometry;
changing the text itself can naturally change its height. The host owns any space
reservation required for asynchronously loaded text.
