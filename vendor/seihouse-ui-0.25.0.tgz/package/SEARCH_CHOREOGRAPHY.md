# Search choreography

The search bar is a stage for SEIHouse artwork. A product owner describes an idea;
an AI implementation agent supplies static artwork and a choreography recipe.
The owner does not need to write code or operate an animation editor.

**Foundation, 2026-11-16:** this release supplies the stage, timeline, validation,
and search interaction contract. It includes no platform/default scene or holiday
artwork. The Workbench square is a diagnostic fixture, not a design proposal.

## Ownership

- `SEISearchBar` owns input/trigger presentation and the bounded decorative stage.
- The engine owns playback, pause, cleanup, reduced motion, and layout containment.
- A recipe owns actors, poses, timing, and reserved space. It is plain data.
- The artwork map owns static SVG, images, or decorative markup. It is trusted
  application code reviewed alongside the recipe, not executable model output.
- The host owns search results, dialogs, dates, locale, scene selection, asset
  delivery, and replay across visits. There is no runtime AI call, calendar,
  storage, network fetcher, or global scene registry here.

Use the same component in SEN, SEA, or another host. Appearance comes from shared
field tokens or `controlClassName`, not a fork of this engine. The elemental/font
engines remain with their existing owners.

## The agent's workflow

1. Translate the owner's idea into a short sequence: entrance, action, exit/rest.
   Establish the visual direction in the task; do not ask the owner to choose APIs.
2. Read `SEISearchChoreography` and its validation limits. Create a stable recipe
   with `defineSEISearchChoreography`, outside render or memoized by scene inputs.
3. Create original static artwork with named parts. Bind each actor's `artwork`
   key to a React node. Use inline SVG or static images for detailed illustration.
   Missing or null artwork disables the scene. Image-load fallbacks belong to the
   host's artwork component; the engine does not fetch or manage assets.
4. Give every actor a considered `still` pose. It must work without motion and
   after the performance finishes. `opacity: 0` deliberately removes it.
5. Keep search text and the icon legible. Prefer the reserved upper/lower edges
   for movement. Do not remove containment to let art escape into adjacent controls.
6. Validate and preview in the existing Search Bar Workbench entry. Inspect
   390×844 and 1280×800, a narrow real header, dark/light and default/SEN/SEA styles,
   keyboard search, reduced motion, interruption and replay.
7. Test important timing/placement and document assets and intended use. A new
   scene should not need engine changes. Explain an unsupported capability before
   extending the contract.

Do not put timers, requestAnimationFrame loops, CSS animations, animated GIFs,
SMIL, video, canvas loops, portals, event handlers, links or controls in artwork.
Independent motion bypasses the engine's pause and reduced-motion policy. Do not
evaluate strings as code or use selectors targeting the search control. This is
an authoring contract for trusted code, not a sandbox for hostile markup.

## Recipe contract (version 1)

| Field                       | Meaning                                                                         |
| --------------------------- | ------------------------------------------------------------------------------- |
| `version`, `id`             | Version `1`; stable nonempty scene identity.                                    |
| `durationMs`                | 1–5000ms for one complete performance. No automatic loops.                      |
| `space.top`, `space.bottom` | Optional 0–64 CSS pixels reserved in normal layout.                             |
| `actors`                    | 1–24 pieces of art, each with a unique `id` and artwork key.                    |
| `width`, `height`           | 1–128 CSS pixels. Art keeps its size as the stage changes width.                |
| `still`                     | Resting pose for SSR, completion, reduced motion and unavailable animation API. |
| `keyframes`                 | 2–60 full poses per actor, offsets strictly increasing from 0 to 1.             |

Each pose has `x` and `y`: percentages of the whole stage, including reserved
space, with the actor centered on that point. `(0, 0)` is physical top-left and
`(100, 100)` bottom-right, also in RTL. Positions from -100 to 200 allow offstage
entrances/exits. The stage clips at its bounds. Movement stays proportional when
the container resizes, without measurement or animation restarts.

Optional pose values: `opacity` (0–1, default 1), `rotate` (degrees, -3600–3600,
default 0), and `scale` (0–4, default 1). Specify a full pose at each frame;
omitted values use defaults, not the previous frame's values. A frame's `easing`
governs travel to the next frame: `linear` (default), `ease`, `ease-in`, `ease-out`,
or `ease-in-out`. Repeated poses create holds. All actors share one timeline.

`defineSEISearchChoreography(recipe)` throws an author-facing error for invalid
data. `validateSEISearchChoreography(unknown)` returns errors, empty when valid.
The component validates again and renders a plain bar for an invalid recipe or
missing art. Never mutate a recipe in place.

## Host integration

```tsx
import { SEISearchBar, type SEISearchDecoration } from "@seihouse/ui";
// Import @seihouse/ui/styles.css in the host's Tailwind stylesheet.
// The host chooses a reviewed recipe and static artwork, or no decoration.
declare const selectedScene: SEISearchDecoration | undefined;

<SEISearchBar
  aria-label="Search albums"
  placeholder="Find an album"
  decoration={selectedScene}
  value={query}
  onChange={(event) => setQuery(event.target.value)}
/>;

<SEISearchBar
  mode="trigger"
  aria-label="Search stories"
  placeholder="Find a world"
  aria-haspopup="dialog"
  aria-expanded={searchOpen}
  onClick={openSearch}
  decoration={selectedScene}
/>;
```

Input mode passes native input events, form attributes and `ref` to `SEIInput`.
It does not install an Enter handler or wrap itself in a form; the host owns
submission. Trigger mode uses `SEIButton`, always `type="button"`, and opens
nothing on focus. Pass the host dialog's ARIA attributes when applicable.
Both require `aria-label` or `aria-labelledby`, separate from the placeholder.
`className` styles the stage; `controlClassName` styles the control.

## Playback and resilience

- No decoration means no stage, observers, listeners or animation work.
- A recipe plays once per mount when visible and permitted. Equivalent data in
  a newly allocated object does not replay it. Change `replayKey` deliberately
  for another performance; changing recipe contents also starts a new performance,
  even with the same ID. Validation is cached by recipe/artwork references.
- Focus, typing and trigger activation keep the artwork visible and the current
  performance running through its natural completion. Search updates do not replay it.
- `animationPaused` is host-controlled. Disabled/loading states pause the timeline
  and hide artwork. Re-enabling resumes rather than restarting it.
- Offscreen stages and hidden documents pause, then resume at their prior time.
- Reduced motion uses still poses without creating animations. Turning it on
  during playback cancels that performance. Turning it off does not replay it
  until the host explicitly requests another performance.
- Completion restores the still poses. Five seconds is the maximum performance;
  repeated/ambient motion and scheduling are outside this first contract.
- Unmount, recipe replacement and replay cancel old animations and remove
  observers/listeners. Unsupported/failing Web Animations APIs use still poses.
- Artwork is inert, accessibility-hidden, pointer-transparent, clipped, and below
  the control's text/icon. Forced colors hide it. Client render failures in artwork
  are isolated from the search control. Artwork must also be safe to server-render.

The engine uses the browser's [Web Animations API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Animations_API/Using_the_Web_Animations_API),
with no new runtime dependency or per-frame React updates.
Artwork transforms identical to their resting pose use inline styles instead of
an extra animation. The carrier still supplies the shared playback clock.

## NovelExpanded: A Sword Opens the World

**First official scene, 2026-11-16, package 0.24.0.** The foundation above is
unchanged. This opt-in scene uses its existing contract; it is never automatically
attached to another product's search bar.

```tsx
import { SEISearchBar } from "@seihouse/ui";
import { novelExpandedSearchDecoration } from "@seihouse/ui/search-scenes/novel-expanded";

<SEISearchBar
  aria-label="Search worlds"
  placeholder="Find a world"
  decoration={novelExpandedSearchDecoration}
/>;
```

The same decoration works with `mode="trigger"`. The subpath also exports
`novelExpandedSearchChoreography` for inspection. Keep the decoration stable and
let the host decide when to mount or explicitly replay it. Ordinary query updates
do not replay it. Import the usual `@seihouse/ui/styles.css`; no scene CSS or assets
need loading. Text inks follow the host's light/dark theme. Gold, jade and vermilion
are original palette choices, independent of a host's accent color.

The performance lasts **4.8 seconds** and reserves **44px above the field**. Allow
that space in the header; do not squeeze it into a fixed 46px row. Designed for
search widths of 180px and up. Thirteen actors share the engine clock: three ink
mountain layers, a moon, two mist banks, two Qi wakes, one sword and four sparks.
All artwork is original inline SVG in `src/search/scenes/novel-expanded.tsx`.
Gradients use per-instance React IDs so multiple bars can share the recipe safely.
There are no downloaded images, fonts, sound, external asset requests, or runtime AI.

- **0–1s:** the mountains emerge and the mist starts to part.
- **1–3.6s:** a jade-hilted sword with a vermilion tassel crosses the upper edge,
  leaving two thin gold currents and four fading motes.
- **3.6–4.8s:** the wake dissipates into a still ink landscape and small moon.
- **Rest/reduced motion:** the same quiet landscape; the sword and Qi are absent.
- **Focus/typing:** the artwork stays visible and the scene plays through its natural completion.

Inspect the existing Search Bar Workbench variant `novel-expanded`. Its replay
button and search-submission message are preview controls, not shipped scene UI.

### Creative implementation prompt

Act as a wuxia art director and frontend motion engineer. Make NovelExpanded's
search feel like the threshold to an unexplored world: **A Sword Opens the World**.
Locate the universal `SEISearchBar` and its choreography contract first. Work only
in its opt-in scene files and existing preview; preserve search semantics, host
layout, theme tokens, engine lifecycle and all unrelated UI.

Use Tier 2 original SVG illustration with Tier 1 transform/opacity motion driven
entirely by the existing Web Animations choreography engine. Paint fine ink-wash
mountains, a restrained gold moon, two translucent mist banks, and a small
jade-hilted flying sword with a vermilion tassel. Let the mist separate, the sword
glide slowly through the center then accelerate out, and thin gold Qi currents
and four motes dissipate behind it. Use small parallax shifts, layered gradient
opacity, tapered strokes and metal facets; no full-screen spectacle.

Play once on visible mount, with explicit host replay. Keep every moving element
in the reserved 44px upper edge so the input text is always clear. Focus and typing
keep the scene visible and playing. Completion and reduced motion share a quiet
mountain-and-moon still. Keep dimensions proportional from a narrow 180px search
slot to desktop. Clip the scene, preserve 44px touch controls, and keep artwork
inert and hidden from assistive technology. Use no extra clocks, independent CSS
animations, canvas, WebGL, network assets, interactive artwork, backend, calendar,
storage or changes to font engines. Inspect phone 390×844 and desktop 1280×800,
light/dark and default/SEN/SEA; check input, trigger, replay, interruption, still
poses and multiple-instance SVG IDs. Report changed files and verification.

## Integrated header (2026-11-16)

`SEIAppHeader` now accepts `decoration`, `backgroundArtwork`, `animationPaused`
and `replayKey`. The same validated player supplies visibility, reduced-motion,
pause and cleanup behavior. Header decoration ignores recipe reserved space;
the host chooses the row height. The decorative layer spans the header, clips
its own artwork, and stays inert behind the entire interactive row. The header
itself does not clip menus or focus outlines. Static background artwork must
follow the same trusted, noninteractive artwork contract.

Import `novelExpandedHeaderDecoration` and `NovelExpandedHeaderLandscape` from
`@seihouse/ui/search-scenes/novel-expanded`. Pass the former as `decoration` and
`<NovelExpandedHeaderLandscape />` as `backgroundArtwork`. Use a 72px inner row
and translucent search/profile surfaces. Put an undecorated `SEISearchBar` in
the header actions. The existing search-only recipe remains available for hosts
that deliberately want the reserved strip. The existing NovelExpanded Workbench
variant now demonstrates the integrated arrangement. Consumer app adoption and
package publication are separate from this UI package change.
