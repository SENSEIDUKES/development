import { createElement } from 'react';

const wordmark = new URL('./assets/novel-expanded-320.webp', import.meta.url).href;
const largeWordmark = new URL('./assets/novel-expanded-640.webp', import.meta.url).href;
const retinaWordmark = new URL('./assets/novel-expanded-1280.webp', import.meta.url).href;
const sizes = { sm: 32, md: 40, lg: 56, xl: 80 };

/** Browser React component. The host owns links, placement and theme selection. */
export function NovelExpandedLogo({ size, theme = 'dark', animated = true,
  alt = 'Novel Expanded', imageSizes, className = '', style, ...attributes } = {}) {
  const height = typeof size === 'string' ? sizes[size] : size;
  if (size !== undefined && !(Number.isFinite(height) && height > 0)) {
    throw new RangeError('NovelExpandedLogo size must be a positive number or sm, md, lg, xl.');
  }
  return createElement('span', {
    ...attributes,
    className: `ne-logo ${className}`.trim(),
    'data-slot': 'novel-expanded-logo',
    'data-theme': theme,
    'data-animated': animated ? 'true' : 'false',
    style: { ...style, ...(height === undefined ? {} : { '--ne-logo-height': `${height}px` }) },
  },
  createElement('span', { className: 'ne-logo__aura', 'aria-hidden': true }),
  createElement('span', { className: 'ne-logo__ring', 'aria-hidden': true }),
  createElement('span', { className: 'ne-logo__face' },
    createElement('img', { className: 'ne-logo__image', src: wordmark,
      srcSet: `${wordmark} 320w, ${largeWordmark} 640w, ${retinaWordmark} 1280w`,
      sizes: imageSizes ?? (height === undefined ? '48px' : `${Math.ceil(height * 1.2)}px`),
      width: 320, height: 198, alt, decoding: 'async', draggable: false })),
  );
}
