# SEN UI (`@seihouse/ui/sen`)

**@seihouse/ui 0.21.0:** The Library UI package was folded into `@seihouse/ui/sen`. The notes below predate the move and keep their original package version numbers.

**0.12.1:** Supports universal UI `^0.16.0 || ^0.17.0`.

**0.12.0:** Requires universal UI `^0.16.0`. Bottom navigation is a visual token
skin over the shared dock variant. The base owns focus, High Contrast and reduced
transparency fallbacks, 52px touch targets, 12px labels and measurable nav refs.

**0.11.0:** Requires universal UI `^0.15.0`. Redesigns `LibraryButton` and `ManifestButton` with a grounded dark-obsidian fill across all filled variants, sleek `rounded-xl` (`12px`) corners matching `.glass-field`, compact sans-serif lettering, locked height + minimum/maximum width size tiers with single-line ellipsis truncation by default, and full prop/variant parity with `SEIButton`.

**0.10.3:** Accepts universal UI `^0.11.0 || ^0.12.0 || ^0.13.0 || ^0.14.0`; no Library component behavior changes.

**0.10.2:** Accepts universal UI `^0.11.0 || ^0.12.0 || ^0.13.0`; no Library component behavior changes.

**0.10.1:** Accepts universal UI `^0.11.0 || ^0.12.0`; no Library component behavior changes.

**0.10.0 (2026-10-06):** requires universal UI 0.11.0. Library navigation
scrollbars appear during scrolling or thumb dragging, then fade after one idle
second even while hovered. Sidebar frames and left/right modal drawers carry a
gold-and-cyan bevel. For a desktop Pathways sidebar, pass
`sidebarBehavior="double-tap"` to `SEIAppShell` (or a standalone
`LibraryNavigationDrawerPanel`): double tap/click anywhere to minimize or expand,
with immediate single-tap navigation and a keyboard-focus-only width control.
No star is rendered in this mode. Mobile modal close behavior is unchanged.

The SEN (SEIHouse Expanded Novels) presentation layer ships inside `@seihouse/ui`
behind its own entry point. Its panels, cards, controls, navigation, glyphs and
particles use the existing `sen` experience. Routing, authentication, storage,
generation and audio playback remain host responsibilities.

| Export                 | Built file                           | Purpose                                                                          |
| ---------------------- | ------------------------------------ | -------------------------------------------------------------------------------- |
| `@seihouse/ui/sen`     | `dist/sen/index.js` and `index.d.ts` | SEN components and their public types                                            |
| `@seihouse/ui/sen.css` | `dist/sen.css`                       | Shared UI tokens/source registration, SEN utility vocabulary, glass/spectral CSS |

The dependency direction is one way: `sen` composes the universal components; the
universal entry (`@seihouse/ui`) and stylesheet (`@seihouse/ui/styles.css`) never
import or scan SEN, so apps that do not use SEN do not load it. Motion is a
runtime dependency used only by the SEN artwork.

The former `@seihouse/library-ui` package is retired. Replace
`@seihouse/library-ui` with `@seihouse/ui/sen` and
`@seihouse/library-ui/styles.css` with `@seihouse/ui/sen.css`; every export
name is unchanged.

## Panel and Card are the universal components (0.22.0)

There is no separate SEN panel or card. Inside `data-experience="sen"`, with
`@seihouse/ui/sen.css` loaded, the universal `SEIPanel` and `SEICard` wear the
Celestial glass look:

```tsx
import { SEICard, SEIPanel } from "@seihouse/ui";

<div data-experience="sen">
  <SEIPanel variant="callout">Guidance</SEIPanel>
  <SEICard title="Astral Compass" description="A guide between worlds." />
</div>;
```

- Panel variants `default`, `callout` and `footer`, and card variants `default`
  and `callout`, take the skin. Every other variant keeps its universal look.
- The skin is two stylesheets, `sen/library-panel.css` and
  `sen/library-card.css`. They fill the `--sei-panel-*` and `--sei-card-*` slots
  the universal components read and add the glass layers. They hold no behavior.
- `LibraryPanel`, `LibraryCard` and the `LibraryCard*` parts remain as deprecated
  names. They render the universal component with `data-skin="sen"`, so they keep
  the look even outside an SEN scope. New code should use `SEIPanel` / `SEICard`.

## Consume the built artifact

Build with `pnpm build:package`, then pack the one package:

```sh
npm pack ./packages/seihouse-ui --pack-destination ./output
```

Install the tarball in a host with the declared peers. The application uses
Tailwind CSS v4. Import CSS once (`sen.css` already includes the universal styles):

```css
@import "tailwindcss";
@import "@seihouse/ui/sen.css";
```

```tsx
import { LibraryPanel, LibraryTextBox, ManifestButton } from "@seihouse/ui/sen";

export function WorldForm() {
  return (
    <section data-experience="sen" data-theme="dark">
      <LibraryPanel>
        <LibraryTextBox label="World name" defaultValue="Astral realm" />
        <ManifestButton type="submit">Manifest World Blueprint</ManifestButton>
      </LibraryPanel>
    </section>
  );
}
```

CSS is explicitly imported rather than evaluated by the JavaScript entry, so
Node SSR and native ESM can load the package. The CSS registers shipped JS with
Tailwind; no workspace source alias or host `node_modules` scan is needed.
Importing this CSS alone without a Tailwind v4 build does not generate utilities.

Font families retain the reference: Rubik, Noto Serif, Alegreya and Alegreya SC.
The host supplies these fonts under its font-loading policy; serif/system
fallbacks remain available. The package performs no remote font requests.
SEN utility colors and font names are prefixed `sen-` to avoid overriding the
universal or host Tailwind theme. Existing `--library-card-*`,
`--celestial-accent` and spectral/glass class hooks are retained.

## Public components

### Library automatic Pathways rail (0.8.0)

Nested items now stay grey when inactive and turn white with a soft white icon
glow and guide marker when active. The parent keeps its blue active pill. The
Library skin sets the shared child tokens; it does not own nested-item behavior.

For laptop sidebars, pass `sidebarMode="automatic"` (or
`defaultSidebarMode="automatic"`) to `SEIAppShell`. Its default resting state is
the 4.5rem compact rail; pointer proximity or keyboard focus expands it. The
star beside the profile pins it open and changes to an unpin action. A host may
persist the `onSidebarModeChange` result or expose `"compact"` as an advanced
compact-only setting. The Library package does not store preferences. Existing
boolean collapse props, default panels, and phone/tablet drawers remain valid.

### Library Pathways refinements (0.7.0)

Library uses the shared 0.8.0 Pathways renderer for conditional nested sections,
an account at the top, scroll fades and a collapsible rail. Active children have
an icon glow, tinted label and small marker on the guide line. Their
active parent keeps the portal-blue pill. Inactive children stay smaller, muted
and unbadged in both expanded and compact density. Library sets the new shared
child, account-ring and scrollbar tokens; the behavior remains universal.

Supply `account={{ name, detail: cultivationRank, avatar, onSelect }}` to show
a profile picture and rank at the top. It wins over `identity` in Pathways; the
existing `profile` adapter also accepts `onSelect`. A placeholder avatar and
`name: "Sign in"` use the same layout. `SEIAppHeader.center` is where the host
can place Dao Insights beside its Library logo/badge and actions on laptops;
Library UI does not embed that application content.

Use the shell's optional `sidebarCollapsed`, `defaultSidebarCollapsed`,
`onSidebarCollapsedChange` and `sidebarCollapsedWidth="4.5rem"` to coordinate
the width and panel density. The shell does not persist the choice. The legacy
drawer remains the phone/tablet navigation; its existing default variant,
`mobileOnly`, profile and section contracts are unchanged. Workbench and
Storybook show the account, signed-out, active-child, scroll, collapse, header
and long-label states.

### Library Pathways (0.6.0)

`LibraryNavigationDrawerPanel` and `LibraryNavigationDrawer` are skins over
`SEINavigationDrawerPanel` / `SEINavigationDrawer` from `@seihouse/ui@^0.7.0`.
Install the two new artifacts together. The universal package owns item lists,
nesting, accessibility, scrolling, artwork, compact tooltips and modal behavior.
Library supplies typography, surface/active tokens, ornaments and compatibility
adapters. There is no second navigation renderer.

The existing default appearance, item fields (`id`, `label`, `icon`, `active`,
`accent`, `required`, `trailing`, `onSelect`), section labels/taglines/icons/guidance,
profile header, close label, and `mobileOnly=true` behavior remain available.
Use `variant="pathways"` explicitly to apply the new presentation. Story Seed's
new preview opts in while its existing consumers retain their default skin.

```tsx
<LibraryNavigationDrawerPanel
  aria-label="Library Pathways"
  variant="pathways"
  identity={{
    name: "Celestial Library",
    wordmark: (
      <>
        Celestial
        <br />
        Library
      </>
    ),
    emblem: { src: libraryEmblemUrl, alt: "Celestial Library emblem" },
    divider: true,
  }}
  sections={[{ id: "pathways", label: "Pathways", items: libraryDestinations }]}
  artwork={{ type: "image", src: libraryLandscapeUrl }}
  footer={{ divider: true, items: libraryUtilityRows }}
/>
```

The host supplies all identity text, media and rows; Help and Settings are preview
choices, never built-in destinations. `divider: true` adds the Library star
between gold hairlines; `false` removes it, and a node supplies a custom ornament.
Active rows combine a gold leading accent with portal-blue glow. Existing `gold`
and `portal` item accents remain accepted. The skin fades artwork into its panel.

All universal panel options are exposed, including `account`, `actions`, `footer`,
image/video `artwork`, `density="compact"`, `href`, and one level of item `children`.
Children have their own `active` and `onSelect`/`href`. Profile retains `name`,
`detail`, `eyebrow`, and optional custom `emblem`; supplying it maps to the shared
account header. `closeLabel` still defaults to `Close menu`.

Compose the panel in `SEIAppShell.sidebar`, with `sidebarWidth="14rem"` and
`sidebarBreakpoint="lg"`. For compact mode use `sidebarWidth="4.5rem"`; nested
destinations, status text and footer controls stay accessible, with focus/hover
tooltips. Custom footer nodes must fit their host rail. Identity and footer remain
fixed while the destination area scrolls. Artwork shrinks first on short panels.

Video accepts an optional `poster` and is always decorative, muted, looping,
inline and without controls. Reduced motion replaces it with the poster (or the
calm surface when absent), including when preferences change after mounting.
See the universal README for the full slot, token and media contracts.

Workbench variants: legacy `sen`, `pathways-home`, `pathways-cave`,
`pathways-story-seed`, `pathways-compact`, and `pathways-short`. The Workbench owns
its landscape/emblem fixtures; neither package includes those assets or URLs.

- `LibraryPanel`: polymorphic glass section container. See [Library panels](#library-panels).
- `LibraryCard`: static, button or link cards; `default` and `callout` skins,
  accent colors, padding and convenience slots. Compound exports:
  `LibraryCardMedia`, `LibraryCardContent`, `LibraryCardHeader`, `LibraryCardTitle`,
  `LibraryCardDescription`, `LibraryCardBody`, `LibraryCardMetadata`,
  `LibraryCardActions`, `LibraryCardFooter`.
- `LibraryButton`: liquid glass pill; `primary`, `secondary`, `ghost`, `danger`;
  `sm`, `md`, `lg`, `icon`; refs, icon slots, `iconSize`, custom loading indicator
  and native props. See [Liquid glass buttons](#liquid-glass-buttons).
- `ManifestButton`: the same glass in its brightest gold, with the spectral rim
  and rainbow halo kept; the same behavior and sizing.
- `LibraryTextBox`, `LibraryTextArea`: glass fields, labels/helper/error IDs,
  controlled string callbacks, uncontrolled native values, icons, overlays,
  compact mode, required/disabled state and textarea character count.
- `LibraryHeaderBadge`: title, subtitle, optional emblem and home link; use
  `mode="app-header"` for inline, non-heading composition inside `SEIAppHeader`.
- `LibraryNavigationDrawer`, `LibraryNavigationDrawerPanel`: controlled modal
  and standalone sidebar, grouped destinations, profile and close labels.
- `LibraryBottomNavigation`: presentational destinations, selection callbacks,
  optional visually hidden labels, safe-area dock and a React 19 nav `ref`.
  It selects `SEIBottomNavigation`'s shared `dock` variant and supplies only
  Library visual tokens; base-owned focus, accessibility fallbacks, slots and
  labels are shared. Hosts may measure the ref with `ResizeObserver` when
  reserving space in overlapping content (see the universal UI README).
- `LibraryDragonCycleIcon`, `LibrarySoundGlyph`: specialized cycle and sound
  vocabulary, decorative/informative accessibility contracts.
- `ParticleEffect`: accent-derived celestial particles with embedded glyphs,
  foreground calm zones, speed and dispersion controls; no host asset URLs.

All reference public `Library*`, `ManifestButton` and `ParticleEffect` prop types
are exported with their existing names. Raw shared primitives and `cn` come from
`@seihouse/ui`; they are not duplicated or re-exported by Library UI.

## Library panels

`LibraryPanel` renders a `div` by default. Use `as` to choose `div`, `section`,
`article`, `aside`, `header`, or `footer`; native HTML attributes, event handlers,
and a React 19 `ref` to the rendered `HTMLElement` are forwarded. The caller is
responsible for choosing an element appropriate to its content.

- `variant` selects `default` (spectral glass), `callout` (gold-tinted inset),
  or `footer` (a flat action strip). The default is `default`. The rendered
  `data-variant` always reflects the selected skin, even if a caller supplies
  an attribute with the same name.
- `padding` selects `none` (0), `sm` (1rem), `md` (1.25rem, 1.5rem from the
  `sm` breakpoint), or `lg` (1.5rem, 2rem from `sm`). The default is `md`.
  Unknown runtime values fall back to the default variant or padding.
- `className` is merged last, so host Tailwind utilities can override the skin
  and padding. The panel clips overflow; give long unbroken content a wrapping
  class when it must remain visible.

For a full-width footer, use an unpadded outer panel and put padding on its
content. Its rounded, overflow-hidden surface clips the footer's lower corners:

```tsx
<LibraryPanel as="section" padding="none">
  <div className="p-5">A story in progress</div>
  <LibraryPanel as="footer" variant="footer">
    Manifestation actions
  </LibraryPanel>
</LibraryPanel>
```

## Liquid glass buttons

`LibraryButton` and `ManifestButton` share one glass recipe, defined in
`sen/library-button.css` and shipped through `@seihouse/ui/sen.css`
(import it once; no extra setup). It lives in `@layer components`, so any
utility class a host passes in still wins. Sizing, padding, the full-pill shape
and the label type stay in the components; the stylesheet only sets colour.

- **Body:** a translucent fill over a blurred, saturated backdrop (10px blur
  below `sm`, 14px from `sm` up), a soft top light and a darker lower lip.
- **Rim:** a 1px specular edge, bright top-left and bottom-right. `ManifestButton`
  keeps its own iridescent `SPECTRAL_EDGE` rim and its rainbow halo instead.
- **Variants** are `data-variant` blocks that set custom properties
  (`--glass-fill`, `--glass-fill-hover`, `--glass-fill-press`, `--glass-text`,
  `--glass-text-hover`, plus rim and glow). To add one, add a block that sets
  those; do not pass per-page colour classes.
  `primary` is gold glass, `secondary` clear glass, `danger` ruby glass, `ghost`
  has no glass at rest and condenses on hover, press and keyboard focus.
- **States:** hover lifts and brightens (only where hover exists), a sheen sweeps
  once, press squeezes and springs back, keyboard focus draws the portal ring as
  an `outline` (so no other state can replace it). `loading` stays full glass with
  its spinner; `disabled` goes flat and desaturated, not just faded.
- **Fallbacks:** denser fill without `backdrop-filter`; solid surfaces under
  `prefers-reduced-transparency`; no sweep, lift or squeeze under
  `prefers-reduced-motion`; system colours, real borders and a `Highlight`
  outline under `forced-colors`.

Glass only shows what is behind it, so preview it on art, not a flat canvas; the
Workbench `LibraryPanel`, `LibraryButton`, `ManifestButton`, and
`LibraryBottomNavigation` entries do. The Bottom Navigation and Library dock
entries share one fixture, with three/four/five destinations, icon-only and long
labels; their context example shows both over art with independently scrolling
content above the navigation. `LibraryPanel` also renders on `GlassStage`. Inside a surface that
already blurs (`LibraryPanel`, `LibraryCard`) a button blurs that surface's own
content rather than the page behind it; the rim, light and shadows carry the glass.
The label is medium weight: Alegreya SC has no 600, and hosts that load only
regular and bold fall back to regular.

## Independent verification

`/sen` in the workbench shows the core set. Each of the 16 families has its
own catalog entry; Storybook examples appear under `Library UI`. Both preview apps
resolve Library UI's built exports. Run `pnpm build:package` again after changing Library UI
source before using an already running preview server.

```sh
pnpm typecheck
pnpm test:unit
pnpm test:package
pnpm lint
pnpm build
pnpm build:storybook
pnpm exec playwright test test/accessibility/sen-library.spec.ts
```

The package contract installs fresh tarballs outside the workspace, verifies
runtime exports, TypeScript contracts, reproducibility, and compiles the shipped
CSS with Tailwind. Browser checks cover desktop/mobile layout, fields, keyboard
activation, modal focus/dismissal, axe accessibility and changing motion settings.
See [the Prompt 3 migration map](../../docs/library-ui-migration.md) for import mapping
and intentional differences.

## Elemental title (moved)

`LibraryElementalTitle` became `ElementalTitle` in `@seihouse/ui`, and from `@seihouse/ui`
0.18.0 it lives in the font lab as its own package. Neither UI package ships it.

## LibraryScrubber

Transferred from development's chapter manifestation journey on 2026-09-10. The UI package owns this reusable presentation, including all SVG character and gate artwork; no remote assets or generation services are required. Motion is a packaged runtime dependency.

```tsx
import { LibraryScrubber } from "@seihouse/ui/sen";

<LibraryScrubber
  progress={0.69}
  travelerId="cultivator"
  trailStyle="qi-glow"
  destinationId="sect"
  status={{ title: "Chapter 1", state: "Manifesting" }}
/>;
```

Progress is caller-controlled, normalized 0–1; null or non-finite values show unknown progress. This is a progress indicator, not an interactive seek slider. Characters: cultivator, sword-rider, spirit-beast. Trails: qi-glow, starlight-trail, scroll-trail. Destinations: door (gate), sect (temple), cave. Omitted destinations follow the character's recommendation; unknown ids use safe defaults. Optional accent, accentSoft, destinationAccent, status, className and aria-label props support other contexts. Layout needs no Tailwind scanning. Reduced motion freezes unknown-progress drift as well as character and gate animation.

Development adopts this artifact directly; no second scrubber implementation or JourneyScrubber compatibility export remains in its product graph.

## Ownership reconstruction (2026-09-18)

Coordinated with Development PR #227. Version 0.5.0 adds three stateless families:

- `LibraryIcon` and the named `Library*Icon` renderers: 28 embedded Celestial glyphs, with no remote asset requirement or routing logic. Decorative by default; pass `role="img"`, `aria-hidden={false}` and an accessible label for informative use.
- `LibraryCaveBackdrop`: caller-selected image, decorative atmosphere, optional ambient particles. Library owns environment selection, account settings and persistence.
- Manifestation artwork: `ManifestationChamber`, `ChamberForegroundMotes`, `CelestialChannel`, `SwordCultivatorClash`, and `CelestialScrollVessel`. The vessel receives only visual phase, image and placeholder label. It never advances a reveal, creates content or authorizes an operation. SEN owns the general reveal contract; Library adapts it to this visual surface.

The existing scrubber also exports its visual registries and prop types for composition. None of these entries imports SEN, Library behavior, Workshop state, accounts, catalogs, backend services or providers. Historical `data-sen-*` icon selectors are visual CSS/inspection hooks, not a dependency on the narrative engine.

The source artwork was transferred from Development's approved implementation. The original approved baseline was Development `60934256df3e84c5dbb50c917a03b18b038399d2`; ownership work continued on PR #227. Imported artwork is now maintained here. No business rules or production infrastructure were transferred.

### Click-only Pathways sidebar

Opt into `sidebarBehavior="click"` on `SEIAppShell` (inherited by its Pathways
panel) or on a standalone `SEINavigationDrawerPanel` / `LibraryNavigationDrawerPanel`.
The default is open (`pinned`). The always-visible star reports `compact` when
minimized and `pinned` when expanded; pointer proximity, hover, and focus never
change its width. Compact controls expose name-only tooltips. Pass `sidebarMode`,
`defaultSidebarMode`, and `onSidebarModeChange` to control or remember the choice.
An `automatic` mode value is treated as `pinned` in click behavior.

```tsx
<SEIAppShell
  sidebarBehavior="click"
  defaultSidebarMode="pinned"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  sidebar={<LibraryNavigationDrawerPanel variant="pathways" {...navigation} />}
>
  {page}
</SEIAppShell>
```

The shell pushes the page alongside the sidebar and animates both columns for
200ms (instant with reduced motion); labels reveal after expansion. The account
reserves the star's full footprint. The Library skin uses a round gold border.
Omit the behavior option to retain automatic pinning and legacy collapse APIs.
Mobile drawer configuration stays host-owned; keep its existing default variant.

### Shared gold overlay scrollbars (0.9.0)

The UI 0.10.0 decorator powers every Library scroll region. The Library stylesheet
sets the shared scrollbar tokens under `data-experience="sen"`,
`.library-navigation`, and `.library-scrollbars`: a subtle pale-to-deep gold
gradient, widening on hover/drag with a soft gold glow. Use `.library-scrollbars`
on a portalled surface if its host theme does not reach the portal. The same
class can theme a host-owned scroll region decorated with `useOverlayScrollbar`.

No Library-specific scrollbar behavior or copied layout implementation exists.
Native bars are hidden without a gutter, and high contrast restores system bars.
Pathways and bounded lists retain conditional edge fades; App Shell main has none.
See **Scroll Area → overlay** in Workbench and **Scroll/Overlay scrollbars** in
Storybook for the page, sideways lane and long-dialog demonstrations.
