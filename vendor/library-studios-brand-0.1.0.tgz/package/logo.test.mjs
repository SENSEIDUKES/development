import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { NovelExpandedLogo } from './index.js';

const render = props => renderToStaticMarkup(createElement(NovelExpandedLogo, props));

test('standalone logo has one accessible image and hides decorative glow layers', () => {
  const html = render();
  assert.equal((html.match(/<img /g) ?? []).length, 1);
  assert.match(html, /alt="Novel Expanded"/);
  assert.equal((html.match(/aria-hidden="true"/g) ?? []).length, 2);
  assert.doesNotMatch(html, /<button|<a /);
});

test('all size presets and custom dimensions reserve the requested plate height', () => {
  for (const [size, height] of [['sm', 32], ['md', 40], ['lg', 56], ['xl', 80], [24, 24], [128, 128], [256, 256]]) {
    const html = render({ size });
    assert.ok(html.includes(`--ne-logo-height:${height}px`));
    assert.ok(html.includes(`sizes="${Math.ceil(height * 1.2)}px"`));
  }
  for (const size of [0, -1, NaN, Infinity, 'unknown']) {
    assert.throws(() => render({ size }), RangeError);
  }
});

test('hosts control light theme, static mode, decorative labeling and responsive image sizes', () => {
  const html = render({ theme: 'light', animated: false, alt: '', imageSizes: '(min-width: 640px) 46px, 39px' });
  assert.match(html, /data-theme="light"/);
  assert.match(html, /data-animated="false"/);
  assert.match(html, /alt=""/);
  assert.match(html, /sizes="\(min-width: 640px\) 46px, 39px"/);
});

test('host attributes and custom properties survive without overriding component semantics', () => {
  const html = render({ id: 'brand', className: 'header-brand', title: 'Novel Expanded',
    style: { marginInline: '8px', '--ne-logo-height': '56px' } });
  assert.match(html, /class="ne-logo header-brand"/);
  assert.match(html, /id="brand"/);
  assert.match(html, /margin-inline:8px;--ne-logo-height:56px/);
});

test('bundled artwork has bounded file sizes and no dependency on an app public directory', () => {
  for (const [width, limit] of [[320, 16000], [640, 35000], [1280, 90000]]) {
    const asset = new URL(`./assets/novel-expanded-${width}.webp`, import.meta.url);
    const bytes = fs.readFileSync(asset);
    assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
    assert.equal(bytes.toString('ascii', 8, 12), 'WEBP');
    assert.ok(bytes.byteLength < limit);
  }
  assert.doesNotMatch(render(), /\/NovelExpanded\.png/);
});
