# @seihouse/ui

Private, versioned ESM distribution. No registry publication is required.

From the repository root, run `pnpm install --frozen-lockfile`, then
`npm pack ./packages/seihouse-ui --pack-destination <artifact-directory>`.
`prepack` builds JavaScript and declarations from source. Commit the resulting
versioned tarball in the consumer and install it with npm using a `file:`
dependency; commit the generated lockfile (including its SHA-512 integrity).
Record the UI source commit alongside the artifact. Rebuild twice to check
byte-for-byte reproducibility. Keep Node/npm versions fixed when regenerating.

```tsx
import { SEIButton } from "@seihouse/ui";
```

In the host Tailwind v4 stylesheet:

```css
@import "tailwindcss";
@import "@seihouse/ui/styles.css";
```

`styles.css` includes tokens and registers the shipped JavaScript as a Tailwind
source, including variant/focus/responsive classes. It does not include a second
Tailwind preflight. `@seihouse/ui/tokens.css` exports tokens alone for hosts that
manage class generation themselves. CSS files are marked as side effects.
Only the root JS API and these two CSS exports are supported; no private deep imports.
React 19 and the listed peers must resolve without `--legacy-peer-deps` or `--force`.

The workbench and Storybook intentionally alias the root API to source for HMR;
external consumers resolve only built files. Components are not copied into apps.

The experience contract is exactly `default`, `sea`, and `sen`. Set
`data-experience="sea" data-theme="dark"` on the document element for music
products, including portal-based overlays. `data-theme` independently selects
dark or light contrast. Use shared semantic tokens for colors, typography,
fields and glass treatments.

Version 0.3.0 narrows the public experience contract; consumers must select one
of these three values and use the shared tokens before upgrading.

## Product presentation layers (0.4.0)

`SEIButton`, `SEIPanel`, `SEICard`, `SEIInput`, `SEITextarea`,
`SEIBottomNavigation` and `SEIDrawerContent` accept `unstyled` for a
product-owned skin. Existing styled defaults are unchanged. The caller supplies
focus styling when opting out of the default skin; native/keyboard/modal
behavior remains canonical. `SEICard.renderContent` replaces its convenience
slot composition. `SEIButton` additionally accepts `iconSize` and
`loadingIndicator`; bottom navigation accepts `showLabels` (default true).
These are generic extension points; the SEN layer in `packages/seihouse-library-ui`
composes them without creating a reverse dependency.
