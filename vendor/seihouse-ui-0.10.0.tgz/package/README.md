# @seihouse/ui

Reusable SEIHouse React components, interaction contracts, and design tokens.

Install the package and its required React peers:

```bash
npm install @seihouse/ui react react-dom
```

The package is ESM-only. Its `prepack` lifecycle builds JavaScript, declarations,
and CSS from source. Releases are published from the repository's manual GitHub
Actions workflow using npm trusted publishing.

```tsx
import { SEIButton } from "@seihouse/ui";
```

In the host Tailwind v4 stylesheet:

```css
@import "tailwindcss";
@import "@seihouse/ui/styles.css";
```

`styles.css` includes tokens and the Elemental Title stylesheet, and registers the
shipped JavaScript as a Tailwind source, including variant/focus/responsive classes. It does not include a second
Tailwind preflight. `@seihouse/ui/tokens.css` exports tokens alone for hosts that
manage class generation themselves. CSS files are marked as side effects.
Only the root JS API and these two CSS exports are supported; no private deep imports.
React 19 and the listed peers must resolve without `--legacy-peer-deps` or `--force`.

The workbench and Storybook intentionally alias the root API to source for HMR;
external consumers resolve only built files. Components are not copied into apps.

The experience contract is exactly `default`, `sea`, and `sen`. Set
`data-experience="sea" data-theme="dark"` on the document element for music
products, including portal-based overlays. `data-theme` independently selects
dark or light contrast. Use shared semantic tokens for colors, typography,
fields and glass treatments.

Version 0.3.0 narrows the public experience contract; consumers must select one
of these three values and use the shared tokens before upgrading.

## Versioning policy

`packages/seihouse-ui/package.json` is the source of the version published to npm
and used by consuming apps to identify the package copy. A change to runtime
behavior, public props or types, generated styles, or the package dependency
contract must bump this version in the same pull request. The pull request
workflow checks for a bump whenever publishable package files change, excluding
tests and documentation. Before `1.0.0`, use a patch for compatible fixes and a
minor version for new or breaking contracts. After `1.0.0`, use patch for
compatible fixes, minor for additive APIs, and major for breaking changes.

## Product presentation layers (0.4.0)

`SEIButton`, `SEIPanel`, `SEICard`, `SEIInput`, `SEITextarea`,
`SEIBottomNavigation` and `SEIDrawerContent` accept `unstyled` for a
product-owned skin. Existing styled defaults are unchanged. The caller supplies
focus styling when opting out of the default skin; native/keyboard/modal
behavior remains canonical. `SEICard.renderContent` replaces its convenience
slot composition. `SEIButton` additionally accepts `iconSize` and
`loadingIndicator`; bottom navigation accepts `showLabels` (default true).
These are generic extension points; the SEN layer in `packages/seihouse-library-ui`
composes them without creating a reverse dependency.

## Text

`ElementalTitle` is name lettering with an element: rank sets the color, the familiar
sets the element (fire, lightning, frost, celestial, void) and bond tier sets the
strength. Lightning runs on a choreography engine under a page-wide budget that keeps
crowded pages smooth, and official familiars add signatures that play on touch or when
the app asks. Its stylesheet is part of `styles.css`. See the
[component guide](src/text/elemental-title/README.md).

```tsx
import { ElementalTitle } from "@seihouse/ui";

<ElementalTitle as="h2" element="lightning" intensity="legendary" color={rankColor}>
  {readerName}
</ElementalTitle>;
```

## Header components — which one is which

Three components carry "header" in their name and they are not interchangeable.

| Component       | Role                                                                                 | Outline                              |
| --------------- | ------------------------------------------------------------------------------------ | ------------------------------------ |
| `SEIHeader`     | Heading block that opens a section of content: eyebrow, title, description, actions. | Renders a heading (`h2` by default). |
| `SEIPageHeader` | The same block at the top of a page, plus an optional breadcrumb.                    | Owns the page's `h1`.                |
| `SEIAppHeader`  | Persistent application chrome above both of them.                                    | Renders **no heading at all**.       |

`SEIAppHeader` is the top-level header of a focused SEIHouse application. It
stays put while the page underneath changes and answers three questions at
once: which app am I in, where am I inside it, and who am I signed in as. It
carries a branding slot, the app name, an optional contextual/page label, an
optional mobile navigation trigger, an actions slot, and a profile/account slot.

Because it is chrome rather than content, the app name is deliberately a
`<span>`: promoting it would place a competing top-level heading above every
page's own `SEIPageHeader`. Landmarks are explicit for the same reason —
`landmark="banner"` (the default) renders a real `<header>`, and
`landmark="none"` renders a plain `<div>` for hosts that already own the
`<header>`, `SEIAppShell`'s `header` slot being the usual case, so a page never
ends up with a header nested inside a header.

```tsx
<SEIAppShell
  header={
    <SEIAppHeader
      landmark="none"
      appName="SEA Console"
      branding={<SeaMark aria-hidden />}
      contextLabel="Vault"
      navigationTrigger={<MenuButton onClick={openDrawer} aria-expanded={open} />}
      actions={<SearchButton onClick={openSearch} />}
      profile={<AccountButton onClick={openAccount} />}
      onBrandSelect={() => router.push("/")}
    />
  }
>
  <SEIPageHeader title="Recovered fragments" />
</SEIAppShell>
```

Layout contract: the identity group is the flexible column and truncates first,
so a long app or context name shortens rather than pushing the account button
off a phone screen. The bar never reflows to a second row — a growing header
would shift the page beneath it — so hosts with more actions than fit a narrow
viewport collapse them into an overflow menu in the `actions` slot. The context
label stays in the accessibility tree at every width but is only painted from
`sm` up, and the navigation trigger retires at `md` unless
`navigationTriggerVisibility="always"`.

Routing, authentication, account logic, and navigation state stay outside. The
only control the component renders itself is the optional brand button, which
reports intent through `onBrandSelect`.

## App Shell integration

### Automatic Pathways rail (0.9.0)

The optional mode API lets each host expose its own sidebar preferences without
putting storage, routing, or settings UI in the component package:

```tsx
<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  sidebarMode={savedSidebarMode ?? "automatic"}
  onSidebarModeChange={saveSidebarMode}
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio"
      variant="pathways"
      sections={sections}
      account={account}
    />
  }
>
  {page}
</SEIAppShell>
```

`SEISidebarMode` is `"automatic" | "pinned" | "compact"`. Automatic starts as a
compact rail, opens while a mouse/pen is near the sidebar or keyboard focus is
inside it, and closes when neither remains. The expanded panel has a 44px star
button: **Pin sidebar open** locks it open; **Unpin sidebar** returns to
automatic. `"compact"` is a host-selectable compact-only setting and suppresses
the pin. `sidebarMode` is controlled; use `defaultSidebarMode` for shell-owned
UI state. `onSidebarModeChange` reports pin/unpin requests only, so transient
hover never overwrites a saved preference. The same three props work on a
standalone Pathways panel. Mode props take precedence over the older boolean
collapse props when both are supplied. Without any mode or collapse props,
existing shell consumers keep their expanded sidebar and default panel styling.
The phone/tablet drawer keeps its current behavior.

The shell continues to animate the column width, except under reduced motion.
The host may render its own advanced settings for these three modes and persist
the selected mode per device or account. The UI package never stores it.

### Pathways refinements (0.8.0)

`SEIAppShell` can now coordinate a Pathways panel without a second host state:

```tsx
<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  defaultSidebarCollapsed={savedDevicePreference}
  onSidebarCollapsedChange={saveDevicePreference}
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio"
      variant="pathways"
      account={account}
      sections={sections}
    />
  }
  header={
    <SEIAppHeader
      landmark="none"
      appName="Studio"
      branding={logo}
      center={insights}
      actions={actions}
    />
  }
>
  {page}
</SEIAppShell>
```

`sidebarCollapsed` makes the shell controlled; otherwise it starts from
`defaultSidebarCollapsed` (false when omitted) and reports toggles through
`onSidebarCollapsedChange`. The shell stores only current UI state, never a
persistent preference. When collapse is enabled, the panel inherits it and
switches between full Pathways and compact density. A standalone panel may use
`collapsed` and `onCollapsedChange` directly. The toggle is a named 44px button
beside the top account/identity spot; it appears on hover or keyboard focus and
remains visible on non-hover devices. The width transition stops for reduced
motion. These props are optional; the existing 16rem shell sidebar and default
panel appearance remain the same without them.

Pathways `account` takes the top identity spot when both are supplied. Its
`name` and optional rank/detail remain the compact accessible name and tooltip;
`account.onSelect` makes the whole card actionable. `identity` remains the
fallback. A host may pass a signed-out avatar and `name: "Sign in"` through the
same slot. The default variant retains its previous account header.

Pathways shows children only under an active parent. They use smaller unbadged
icons and a separate active accent, configured with
`--sh-nav-child-active-accent`, `--sh-nav-child-active-glow`, and
`--sh-nav-child-active-text`; the default variant retains its existing child
visibility. The items scroller uses the shared overlay scrollbar described below.
Its conditional top/bottom fades mark hidden content; wheel, touch and keyboard
scrolling remain native.
Long Pathways labels use up to two lines and retain a full-label tooltip; section
guidance wraps inside its card.

`SEIAppHeader.center` accepts host content between identity and actions.
`centerBreakpoint` is `"lg"` by default and also accepts `"md"`, `"xl"`, or
`"always"`; `centerClassName` customizes the slot. The center remains at the
header midpoint and shrinks before side content. Content hidden below its
breakpoint is removed from layout and keyboard focus.

### Pathways sidebar (0.7.0)

`SEINavigationDrawerPanel` is the universal sidebar and drawer-content renderer.
Opt into `variant="pathways"` for tall pills, round icon wells and theme-driven
active/focus states. With no new props, its existing account/sections/actions
presentation is unchanged. `SEINavigationDrawer` forwards the same options.

```tsx
import { SEIAppShell, SEINavigationDrawerPanel } from "@seihouse/ui";

<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio navigation"
      variant="pathways"
      identity={{
        name: "Studio",
        emblem: { src: studioEmblemUrl, alt: "Studio emblem" },
        divider: true,
      }}
      sections={[
        {
          id: "workspace",
          label: "Workspace",
          items: [
            { id: "home", label: "Home", icon: homeIcon, active: true, href: "/" },
            {
              id: "projects",
              label: "Projects",
              icon: projectsIcon,
              onSelect,
              children: [{ id: "drafts", label: "Drafts", icon: draftsIcon, onSelect }],
            },
          ],
        },
      ]}
      artwork={{ type: "image", src: landscapeUrl }}
      footer={{
        divider: true,
        items: [{ id: "support", label: "Support", icon: supportIcon, href: "/support" }],
        content: <small>Workspace status supplied by the host</small>,
      }}
    />
  }
>
  {routeContent}
</SEIAppShell>;
```

All example URLs, icons, handlers and route content come from the host. The
package bundles no emblem, artwork, app names, destination lists or remote fonts.

- `identity`: accessible `name`, optional visual `wordmark`, `emblem: { src, alt }`
  and `divider` (`true` for a line, or a decorative node between lines).
- Items retain `id`, `label`, `icon`, `active`, and `onSelect(id)`. Optional `href`
  uses a native link; `onSelect` also observes activation without preventing it.
  `children` is one level deep, with independent current-page states. `required`
  and non-interactive `trailing` content preserve status announcements.
- Sections also accept `icon`, `tagline`, and guidance in `footer`. Section
  guidance scrolls with its destinations.
- Panel `footer` accepts arbitrary `items`, custom `content`, and optional
  `divider`. Legacy `actions` remain supported and render before this footer
  when both are present. An empty footer produces no wrapper or divider.
- `artwork` is `{ type: "image", src }` or `{ type: "video", src, poster? }`.
  Both are decorative. Video is muted, inline, looping and autoplaying, without
  controls. Server rendering and reduced motion use the poster; without a poster
  they use the panel surface. Changing the preference removes the playing video.
- `density="compact"` opts into a named icon rail. Pair it with
  `sidebarWidth="4.5rem"`; density does not resize the host shell. Children remain
  directly reachable below their parent. Missing icons use initials. Every
  built-in control has a focus/hover tooltip; required and trailing text remains
  accessible. Custom footer nodes are host-owned and must fit the compact width.
- `account` remains available alongside identity and gains optional `eyebrow`.
  `closeLabel` defaults to `Close navigation`.
- The modal wrapper's optional `mobileOnly` defaults to false. When true it
  suppresses the modal at 1024px and releases focus and scroll lock. Match a host
  using that mode with `sidebarBreakpoint="lg"`. `side` remains left/right.

The panel fills its bounded parent. Identity/profile and footer do not scroll;
only destinations scroll. Decorative artwork yields space first, shrinks below
800px, and hides at 650px or less (both panel and viewport height). Without
artwork, remaining space still separates navigation from the footer. Keep custom
identity/footer content small enough to leave room for destinations.

Pathways uses `--sh-nav-*` custom properties with neutral semantic defaults:
`surface`, `text`, `muted`, `font`, `identity`, `divider`, `hover`, `selected`,
`selected-text`, `accent`, `focus`, `active-border`, `active-shadow`, `active-icon`,
`icon-border`, `icon-surface`, `row-height`, `icon-size`, `radius`, `gap`, and
`artwork-opacity`. Set overrides on the panel using `style`, or a theme rule
targeting `[data-slot="navigation-panel"]`. Keep row targets at least 44px.
Forced colors preserves outlines and selection independently of artwork/glow.

Product skins can use `unstyled`, `classNames`, `closeButton`, `surfaceProps`,
and `panelClassName` without replacing rendering or modal behavior. The optional
`classNames.tooltipPositioner` controls portaled tooltip stacking for hosts with
a custom modal layer. `closeButton` receives the shared handler and close label.
`surfaceProps` is a drawer-surface hook; panel props remain on the panel.

Workbench: Navigation Drawer includes image, video, no-artwork, compact and short
variants. App Shell includes Pathways with a live `sidebarBreakpoint` control.

`SEIAppShell` owns the outer app layout: it renders one `<main>` landmark, keeps
the header and optional footer in place, and scrolls long main and sidebar
content inside the available height. Put the route view directly inside the
shell; do not add another `<main>` around it. Give `mainId` a page-unique value
and place a skip link before the shell so keyboard users can jump to that
region:

```tsx
import { useRef } from "react";
import { SEIAppHeader, SEIAppShell, SEIBottomNavigation } from "@seihouse/ui";

function AppLayout() {
  const mainRef = useRef<HTMLElement>(null);

  return (
    <>
      <a className="sr-only focus:not-sr-only" href="#app-main">
        Skip to main content
      </a>
      <SEIAppShell
        mainRef={mainRef}
        mainId="app-main"
        sidebarBreakpoint="lg"
        header={<SEIAppHeader landmark="none" appName="SEA Console" />}
        sidebar={<nav aria-label="Primary">{/* Host-owned links shown at lg+ */}</nav>}
        footerClassName="lg:hidden"
        footer={<SEIBottomNavigation aria-label="Primary" items={mobileDestinations} />}
      >
        <RouteView />
      </SEIAppShell>
    </>
  );
}
```

The shell fills `100dvh` by default and assumes a viewport-contained app with
internal scrolling. To place it inside a bounded host panel instead, give the
parent an explicit height and use `className="h-full min-h-0"` on the shell.
Keep the host's flex/grid ancestors shrinkable (`min-h-0`) as well. For a
document-scrolling page, use the page/layout primitives rather than this app
shell contract. `mainRef` points at the scrollable `<main>` element; the
component's forwarded `ref` continues to point at the outer shell `<div>`.

## File Upload and folder import

`SEIFileUpload` keeps the regular file picker and adds a separately named folder
picker when `allowDirectory` is set. It also recursively reads folders dropped
onto the drop area where the browser exposes directory entries. Folder files
pass through the same accept, size, count, and custom validation as regular
files. Directory selection enables multiple files and preserves browser-provided
`File.webkitRelativePath` values on the `File` objects sent to `onFilesChange`.
Files from a dropped folder carry the same `Folder/sub/file` relative paths,
restored from the dropped directory entries; loose dropped files keep an empty
path, as the regular file picker reports them.
Upload, storage, and folder processing remain host responsibilities.

```tsx
<SEIFileUpload
  allowDirectory
  accept="audio/*"
  maxFiles={250}
  onFilesChange={(files) => queueFiles(files)}
/>
```

The `sidebar` defaults to appearing at `md`; set `sidebarBreakpoint` to `"lg"`
or `"xl"` to delay it. The selected breakpoint controls both sidebar visibility
and the grid column, while the shell leaves responsive navigation to the host.
The host owns route state, the active item, and an alternate mobile drawer or
bottom navigation. If both desktop and mobile navigation are present, give each
landmark an accessible label and hide the inactive one at the same breakpoint.
The `header` slot is already wrapped in a `<header>`, so use
`SEIAppHeader landmark="none"` there.
The optional `footer` is a separate, non-scrolling row; keep its content short
and account for device safe areas with `SEISafeArea` or a navigation component
that already pads for the home indicator. Use `footerClassName` when the whole
row is breakpoint-specific, such as a mobile-only bottom navigation, so the
hidden footer does not leave an empty grid row or border at wider sizes.

Import `@seihouse/ui/styles.css` from the host's Tailwind v4 stylesheet as shown
above in this README. The package stylesheet registers the built component
JavaScript so App Shell's grid, viewport, and overflow utilities are emitted in
the consuming app.

### Click-only Pathways sidebar

Opt into `sidebarBehavior="click"` on `SEIAppShell` (inherited by its Pathways
panel) or on a standalone `SEINavigationDrawerPanel` / `LibraryNavigationDrawerPanel`.
The default is open (`pinned`). The always-visible star reports `compact` when
minimized and `pinned` when expanded; pointer proximity, hover, and focus never
change its width. Compact controls expose name-only tooltips. Pass `sidebarMode`,
`defaultSidebarMode`, and `onSidebarModeChange` to control or remember the choice.
An `automatic` mode value is treated as `pinned` in click behavior.

```tsx
<SEIAppShell
  sidebarBehavior="click"
  defaultSidebarMode="pinned"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  sidebar={<SEINavigationDrawerPanel variant="pathways" {...navigation} />}
>
  {page}
</SEIAppShell>
```

The shell pushes the page alongside the sidebar and animates both columns for
200ms (instant with reduced motion); labels reveal after expansion. The account
reserves the star's full footprint. The Library skin uses a round gold border.
Omit the behavior option to retain automatic pinning and legacy collapse APIs.
Mobile drawer configuration stays host-owned; keep its existing default variant.

### Shared overlay scrollbars (0.10.0)

All package scroll regions use one decorator: scroll areas, horizontal lanes,
virtual lists, App Shell main/sidebar, navigation, dialog/drawer/sheet bodies,
menus/popovers, command/combobox lists, tabs and toast stacks. It hides native
bars without a gutter and paints an aria-hidden overlay thumb inside the same
scroll element. It does not replace native wheel, touch, keyboard or focus
scrolling. App Shell's `mainRef` still points to the scrolling `<main>`.

```tsx
import { SEIOverlayScrollbar, useOverlayScrollbar } from "@seihouse/ui";

// New native scroll region:
<SEIOverlayScrollbar role="region" aria-label="Activity" className="max-h-64">
  {rows}
</SEIOverlayScrollbar>;

// Decorate an existing element; optional second argument forwards its ref:
const scrollRef = useOverlayScrollbar<HTMLElement>({ fades: false }, mainRef);
<main ref={scrollRef} className="overflow-y-auto">
  {page}
</main>;
```

For non-React integration, `attachOverlayScrollbar(element, { fades: true })`
returns a cleanup function. Attach only once per element. The decorator preserves
existing positioning and adds relative positioning to static scroll elements so
its decorative layer has a containing block. No additional scroll container is
created; labels, tabindex and children remain host-owned. The ref hook handles
mounting in portals and forwards ref cleanup as well as the original element.

Theme with `--sh-scrollbar-thumb`, `--sh-scrollbar-thumb-hover` (color or gradient),
`--sh-scrollbar-size` (6px), `--sh-scrollbar-size-hover` (10px), and
`--sh-scrollbar-inset` (3px). `--sh-scrollbar-glow` optionally supplies a hover
box-shadow. Thumbs show while scrolling and for one second afterward, or on hover
on devices with hover capability. They can be dragged without changing native
scroll behavior. ResizeObserver and a frame-batched mutation/scroll observer keep
both axes synchronized, including content that grows or shrinks.

Bounded surfaces use conditional edge masks; main pages have none. Reduced motion
removes the fade; forced colors restores system-native scrollbars. Custom thumbs
are decorative, never additional keyboard stops. The **Scroll Area → overlay**
Workbench preview and **Scroll/Overlay scrollbars** story demonstrate a page,
long list, horizontal lane, virtual list, dialog and menu.
