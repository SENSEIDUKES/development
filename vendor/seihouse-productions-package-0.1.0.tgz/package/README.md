# Ⓢ SEIHouse Productions Package

`.spp` means **SEIHouse Package / SEIHouse Productions Package**. It is the
universal portable container for the entire SEIHouse ecosystem—not a format owned
by SEA, SEN, Signal, or any other single product. Those systems, and future
SEIHouse products, can create and read SPP files without redefining the shared core.

The base format stays reusable and product-neutral. Individual products may layer
their own meaning and behavior around a package, while the package remains portable
outside the app that created it.

Format 1.0 defines package identity and a file inventory in a readable JSON manifest
inside a ZIP container. Create, inspect, validate, and extract it in a browser or Node.

The package is marked `private: true` to prevent accidental npm publication. A
license/distribution policy has not been chosen.

## Open the playground

Requires Node 22.12 or newer and npm. From this folder:

```sh
npm install
npm run dev
```

Open **http://127.0.0.1:4173**. On Windows, you can also double-click
**Start Playground.cmd** after installing dependencies. The server binds only to
the local loopback address. No account, upload service, or network storage is used.
All interface fonts and assets are local; samples are served by the local server.

1. Click **Create sample .spp** to build “A quiet arrival.”
2. Select a file in the tree. See its path, media type, size, fingerprint,
   and any optional metadata.
3. Select `manifest.json` to see package identity, version, and the file inventory.
4. Click **Run validation**, then **Extract assets** to save individual files.
5. Use **Try a problem** to see changed, missing, damaged, duplicate-path, unsafe,
   invalid-tag, and future-version examples. Invalid packs cannot extract.
6. Use **Build with my files** to make a pack and save it.

Audio files have an **Audio tags (optional)** section in the creator. Energy,
Tension, Tone, and comma-separated descriptive tags start blank. Skipped or
cleared tags are omitted from that file's manifest record. Other files have no
audio-tagging controls; existing tags on imported files are preserved. Audio and
non-audio files can travel together in the same package.

The six clickable stages explain **Assets → Manifest → Fingerprints → .spp
Container → Validation → Extraction**. Previews render bounded text; they do not
execute HTML/SVG or play media. Binary assets can be inspected by record and saved.
The browser builder allows up to 100 files, 32 MiB each and 48 MiB total; the package
library has separate documented limits. Creation and validation are in-memory.

## Package API

### Hosting the playground on Vercel

Use the repository root as the Vercel project's Root Directory. The committed
`vercel.json` selects Vite, runs `npm run build`, and serves `playground-dist`,
which contains the website's `index.html`, styles, scripts, and sample packs.
`dist` contains the importable package library and is not the website output.
After merging a hosting configuration change, deploy the updated commit through
the connected Vercel project for it to take effect.

### Build and import the library

```sh
npm run build
```

The build produces ESM, CommonJS, and TypeScript declarations in `dist/`, plus the
local playground build in `playground-dist/`. The universal entry has no Node
filesystem imports. Modern browsers need Web Crypto on localhost or HTTPS;
Node 22.12+ provides the same SHA-256 API. The `/node` entry is Node-only.

```ts
import {
  createPack,
  openPack,
  validatePack,
  inspectPack,
  extractPack,
} from 'seihouse-productions-package';

const bytes = await createPack({
  name: 'First package',
  description: 'A greeting file.',
  files: [
    {
      path: 'assets/hello.txt',
      mediaType: 'text/plain',
      data: new TextEncoder().encode('Hello'),
    },
  ],
});

const pack = await openPack(bytes);
console.log(pack.inspect()); // parsed manifest, entries, asset links and validation
console.log(pack.validate()); // { valid, issues: [{ code, severity, message, path? }] }
if (pack.validate().valid) {
  const assets = pack.extract(); // Map<string, Uint8Array>, copies of verified assets
  const hello = pack.readAsset('assets/hello.txt'); // one verified asset, also a copy
}

// Equivalent one-shot functions:
await validatePack(bytes);
await inspectPack(bytes);
await extractPack(bytes); // throws SppError when validation fails
```

`openPack` returns an inspectable result for malformed packs; `validatePack` reports
their errors. Invalid limit options throw `SppError('INVALID_LIMIT', ...)`.
`createPack` rejects invalid input and computes size/fingerprint itself.
Use `fingerprint(bytes)` separately when needed. `manifestSchema` and `DEFAULT_LIMITS`
are exported. All operations accept optional lower limits (except `fingerprint`).

Any JavaScript/TypeScript app can accept a local `.spp` file without a UI framework:

```ts
import { intakePack } from 'seihouse-productions-package';

const picker = document.createElement('input');
picker.type = 'file';
picker.accept = '.spp';
picker.onchange = async () => {
  const file = picker.files?.[0];
  if (!file) return;
  try {
    const { source, content, inspection, validation } = await intakePack(file);
    console.log(source.name, source.size, inspection, validation);
    if (content) console.log(content.manifest, content.assets);
  } catch (error) {
    console.error('Could not read this input:', error);
  }
};
document.body.append(picker);
```

`intakePack` accepts `File`, `Blob`, `ArrayBuffer`, or `Uint8Array` and optional
lower limits as its second argument. `source.size` is in bytes; `source.name` is
present for named files. It delegates parsing and validation to `openPack` and
snapshots mutable byte inputs before yielding, respecting a typed array's view.
Valid results include `content.manifest` and `content.assets`, a map from asset paths
to original `Uint8Array` bytes. These are host-owned copies; text decoding and use
belong to the receiving app. Invalid results have `content: null`.
See [SPP_AGENT_SETUP.md](SPP_AGENT_SETUP.md) for connecting these contents to an app’s AI context.
Damaged packs return inspection and validation results, but their `pack.readAsset`
and `pack.extract` remain blocked. Oversized inputs reject with `ARCHIVE_LIMIT`
before any browser file read; invalid limits reject with `INVALID_LIMIT`, unsupported
inputs with `INVALID_INPUT`, and browser read failures propagate to the caller.
Intake is in-memory and eagerly copies validated assets into `content`, so it holds
an additional copy of the expanded files. It uses the existing resource ceilings and adds no extension or
MIME-type filtering, product behavior, or persistence.

```ts
import { extractToDirectory } from 'seihouse-productions-package/node';
await extractToDirectory(bytes, './new-output-folder');
```

The parent folder must already exist and be controlled by the caller. The output
folder must not exist. Validation happens before disk writes. This avoids merging
with preexisting files, symlinks, and junctions. See the full extraction threat
boundary and supported ZIP features in [FORMAT.md](FORMAT.md).

## Specification and checks

- [FORMAT.md](FORMAT.md): language-neutral format and safety rules.
- [schema/manifest.schema.json](schema/manifest.schema.json): JSON Schema draft 7.
- [samples/README.md](samples/README.md): committed valid and invalid binary packs.
- [examples/sample.ts](examples/sample.ts): readable sample content.
- [scripts/check-interop.py](scripts/check-interop.py): Python standard-library
  interoperability check, including writing stored and deflated packs for the JS reader.
- [VERIFICATION.md](VERIFICATION.md): final local verification evidence.

```sh
npm run verify        # typecheck, tests, builds, samples, Python interop, package smoke
npm audit            # installed dependency advisories
```

`verify` requires Python 3 on PATH. `npm run test:package` builds an npm tarball
locally, installs it in an isolated temporary consumer, and tests ESM, CommonJS,
schema export, Node extraction, and a browser bundle without source aliases.
It does not publish anything. `npm run samples` regenerates the committed examples.

R2, tagging automation, installation, playback, marketplace, signing, and specialized
media contracts are intentionally absent. The manifest has no required package categories. Fingerprints
check bytes against the manifest; they do not prove who created the package.

Assets do not need Energy, Tension, Tone, or descriptive tags. Existing packages may still include these optional fields. This reader uses format 1.0; earlier 0.1 packages are inspectable but rejected. For example, a basic instructions package can be created with:

```ts
const bytes = await createPack({
  name: 'Author',
  description: 'Author instructions.',
  files: [
    {
      path: 'assets/author-instructions.md',
      mediaType: 'text/markdown',
      data: new TextEncoder().encode('Write clear, useful instructions.'),
    },
  ],
});
// Save bytes as author.spp using your app’s file-saving flow.
```

### Identity and generated fields

The creator asks for a package name, description (which may be empty), and files.
`createPack({ name, description, files })` sets `formatVersion` to `1.0`, generates
a random package ID, defaults `version` to `1.0.0` and `publisher` to
`SEIHouse Productions LLC`, and records the current UTC time. It builds the file
inventory and hashes. Media types are inferred from common extensions, with
`application/octet-stream` for unknown files; API callers can supply a media type.
Names and publisher strings are declarations, not proof of authorship.

For a later version, pass the original ID explicitly:

```ts
const previous = (await intakePack(previousBytes)).content;
if (!previous) throw new Error('The previous package is invalid.');
const nextBytes = await createPack({
  id: previous.manifest.id,
  version: '1.0.1',
  publisher: previous.manifest.publisher,
  name: 'Updated package name',
  description: 'Updated contents.',
  files: previous.manifest.files.map((record) => ({
    ...record,
    data: previous.assets.get(record.path)!,
  })),
});
```

An ID must be supplied when specifying a version other than `1.0.0`. Keep it in
the host’s existing package record across versions, including name changes.
In the playground, **Update opened package** keeps the ID and publisher, copies
the files into the creator, and advances the patch version. **Start a new package**
creates a separate identity. Choosing replacement files while updating keeps the
package identity. Format 1.0 replaces the 0.1 manifest; there is no automatic
migration or fallback. Package `version` and `formatVersion` serve different purposes.
