# SEIHouse Front Desk

`@seihouse/front-desk` gives an app a front desk in one character. It offers:

- help for the page you are on;
- guides that play while you follow along;
- actions it always asks before taking, and "Take me back";
- look-ups that never spoil;
- the free browser voice, typing and live talk.

It is built first for people who cannot, or would rather not, work a screen: the
reader in a hospital bed, the older reader, the worker with busy hands.

Front Desk belongs to the SEIHouse ecosystem, like the UI kit, the fonts and the
audio player. Creators in SEIHouse put their own character on it. Novel Expanded's
is **the Familiar**, and SEA's will be the vocal director. It is private to
SEIHouse Productions for now.

## What a host supplies

A host is the app that uses it. Front Desk brings the card, the voice and the
asking-before-acting. The host brings everything that makes it theirs:

| What | How |
| --- | --- |
| **The character** | `character` (name and description). On the greeting, `guides.face` and where it stands, `guides.perch`. |
| **Its word for the character** | `setup.wording.who`, used in every label and message ("Talk to Basil", "Your Basil could not connect"). Defaults to "Front Desk". |
| **What it says first** | `setup.wording.greeting`, with an optional `greetingNote` under it |
| **The app's docs** | `setup.docs`, a `DocsCatalog`: the only facts it may answer from |
| **Each page's place** | `useFrontDeskContext({ title, topics, actions, hint, page?, place?, knowledge? })`. Actions run only after the person confirms. |
| **Which actions lead** | `setup.policy` (`FrontDeskActionPolicy`): which actions each page may offer, in what order, and which only go somewhere |
| **Code letters** | `setup.codes`: the letters on screen and the words people say for them ("recipe one") |
| **The voice** | `voice`: `createBrowserVoice()` is free, or bring your own. With `play`, recorded lines play on the host's own player. |
| **Live talk** (optional) | `live`: `createGeminiLive`, `createOpenAiLive` or `createRealtimeLive`. They call the host's server route (`/api/familiar-live` unless named) with the host's `accessToken`. |
| **Wake word** (optional) | `wake` (`createWakeWord`) and `wakeWord` |
| **Code badges** (optional) | `renderCode` |

The host also styles the talk button (`FrontDeskTalkButton`, class
`front-desk-talk`, or its own `className`). Import the stylesheet once:
`import '@seihouse/front-desk/styles.css'`.

[`example/main.tsx`](./example/main.tsx) shows a whole host: a recipe app whose front
desk is Basil. Run it with `npm run example`.

## Entries

| Entry | What it holds |
| --- | --- |
| `@seihouse/front-desk` | `FrontDeskController` (modes, proposals it confirms before acting, "Take me back", look-ups that hold spoilers back, typed and spoken commands, live talk calls), `composeFrontDeskContext`, `FrontDeskActionPolicy`, `FrontDeskSetup`, `FrontDeskWording`, spoken codes (`parseSpokenCode`, `SpokenCodeWords`), and the card: `FrontDeskProvider`, `FrontDeskTalkButton`, `useFrontDeskContext`, `useFrontDeskInUse`, `useFrontDeskReadAloud`, `useFrontDeskAvailable`, `FrontDeskGuideView`, `FrontDeskClip`, `FrontDeskGreeting` |
| `@seihouse/front-desk/docs-knowledge` | The docs catalog shape and its look-up: `DocsCatalog`, `DocsCategory`, `DocsTopic`, `lookUpDocs`, `docsIndex`, `searchDocs`. An empty `lookUpDocs` is the honest answer that the docs do not cover a question. |
| `@seihouse/front-desk/engines` | The free browser voice (`createBrowserVoice`), the wake word (`createWakeWord`), and live talk for Gemini (`createGeminiLive`), OpenAI (`createOpenAiLive`) and the OpenAI Realtime protocol on ElevenLabs (`createRealtimeLive`), on one `createLiveEngine` |
| `@seihouse/front-desk/styles.css` | The card, its media spot, guides, clips and the greeting. It carries its own reset, so it looks the same on any page. |

Peers a host provides: React and React DOM 19, `lucide-react`, `react-focus-lock` and
`@seihouse/ui` (the card's scrollbar).

## What stays with the host

- **The live-talk server.** It mints the live session and holds the provider keys,
  so it is host code. Front Desk only calls its route.
- **Names on the wire.** The live brief's `familiar` field, the speaker
  `'familiar'` in captions, and the default route `/api/familiar-live` keep their
  first names, because the server speaks them.

## Working on it

```bash
npm ci
npm run verify   # types, tests, the build, and the packed package on a host of its own
npm run example  # the example host
```

- `npm run check:standalone` packs the build and installs it into an empty
  consumer with only the peers. It checks that no SEN or Library code came along,
  then runs a host of its own (its docs, its actions, its code letters, its word)
  and type-checks one.
- The tests use a sample host ([`src/test/sampleHost.ts`](./src/test/sampleHost.ts)),
  not any SEIHouse app.
- `.npmrc` sets `legacy-peer-deps`. npm 10 stops with an error while resolving
  vitest's optional peers, so every peer is pinned in `devDependencies` instead.

**Releasing to an app:** bump the version in `package.json` and
`FRONT_DESK_PACKAGE_VERSION` (`src/index.ts`), run `npm run verify`, then
`npm pack`. In the app's repository, put the tarball in `vendor/` and point
`@seihouse/front-desk` at it, the way the UI kit is vendored.

## History

- **2026-11-08** (0.2.0) Front Desk moved into its own repository (step 2 of the
  plan in the development repository's `docs/front-desk-plan.md`).
  - The card's classes and hooks now carry its own name: `front-desk-card`,
    `front-desk-guide`, `front-desk-clip`, `front-desk-greeting`, and
    `data-front-desk-*`.
  - The host's word for its character (`wording.who`) fills every label and
    message, and the greeting's words are the host's (`wording.greeting`,
    `greetingNote`).
  - The provider's `familiar` prop is now `character`.
  - The stylesheet carries its own reset.
  - The greeting's focus lock also loads in plain Node (a host's tests or server), not only through a bundler.
  - Its tests run on a sample host, and an example host and a standalone check
    were added.
  - Kept: `@seihouse/ui` as a peer (SENSEI: the scrollbars are made for SEIHouse's
    users), and the live-talk wire names.
- **2026-11-08** (0.1.0) Separated from Novel Expanded's Familiar inside the
  development repository (step 1). That moved:
  - the controller, spoken codes, card, guide view, clip and greeting;
  - the voice, wake word and live engines;
  - the docs look-up.

  What reached into the app became inputs.
- **2026-11-06** (docs look-up) A category can be `unlisted`: looked up when asked
  for, never named in the index. The first was a story's spoilers.
- **2026-11-05** (docs look-up) Created, so the character looks entries up instead of
  carrying the whole catalog in every live instruction.
