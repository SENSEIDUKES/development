# Ⓢ SEIHouse Productions Package (.spp), format 1.0

`.spp` means **SEIHouse Package / SEIHouse Productions Package**. It is the
universal portable container shared across the SEIHouse ecosystem. SEA, SEN,
Signal, and future SEIHouse products may build on it, but no single product or use
case defines the base format.

An `.spp` is one ZIP file containing an inventory (`manifest.json`) and the original
bytes of zero or more assets. It groups files and checks their integrity. It does
not install, execute, play, publish, or authenticate them. Product-specific meaning
and behavior belong above this shared container rather than being assumed by it.

This document and [the JSON Schema](schema/manifest.schema.json) define the format
independently of TypeScript. JSON Schema validates the shape of the manifest;
the container and cross-record rules below are also required. Implementations in
Python, Rust, Go, or another language must apply both. The reference package is
an implementation of these rules, not the only source of truth.

## Container layout

```text
my-production.spp                 ZIP file, regardless of extension
├── manifest.json                exactly one, at the root
└── assets/                      implicit folder, no directory entry
    ├── story/arrival.txt        original bytes
    └── design/lantern.svg       original bytes
```

Every asset record describes exactly one file under `assets/`. Every file other
than `manifest.json` must have a record. Directory entries are unnecessary and
not accepted. Internal order has no meaning. Extracting a pack produces the asset
files; the API exposes the manifest separately through inspection.

## Manifest

UTF-8 JSON, without a byte-order mark, duplicate object keys, or non-finite numbers.
JSON nesting is limited to 64 containers (objects or arrays). No comments. Keys
and IDs are case-sensitive. The fingerprint is computed over file bytes, not
JSON text or a normalized representation of a file.

```json
{
  "formatVersion": "1.0",
  "id": "stable-package-id",
  "name": "Package Name",
  "version": "1.0.0",
  "description": "What the package contains.",
  "publisher": "SEIHouse Productions LLC",
  "createdAt": "2026-01-01T00:00:00.000Z",
  "files": [
    {
      "path": "assets/example.md",
      "mediaType": "text/markdown",
      "sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    }
  ]
}
```

The example file contains exactly the three UTF-8 bytes `abc`.

| Required field   | Contract                                                                                                                                                                              |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `formatVersion`  | Exactly `1.0`. This identifies the manifest contract, not the package release.                                                                                                        |
| `id`             | Stable, nonblank package identifier, at most 128 characters. Generated once for a new package and retained across all later versions.                                                 |
| `name`           | Nonblank display name, at most 256 characters. Renaming does not change the ID.                                                                                                       |
| `version`        | Semantic version string, at most 128 characters, e.g. `1.0.0`. Numeric major, minor, and patch; optional prerelease and build identifiers.                                            |
| `description`    | String, at most 4096 characters; an empty description is allowed.                                                                                                                     |
| `publisher`      | Nonblank declared publisher, at most 256 characters. This is not verified authorship.                                                                                                 |
| `createdAt`      | Valid UTC calendar date and time in `YYYY-MM-DDTHH:mm:ss[.sss]Z` form. Fractional seconds are optional, with one to three digits. Leap seconds and timezone offsets are not accepted. |
| `files`          | Array of at most 1023 file records. Empty packages are allowed.                                                                                                                       |
| File `path`      | Unique portable relative path under `assets/`, subject to the rules below. This identifies the file within the package.                                                               |
| File `mediaType` | Type/subtype string without parameters, at most 255 characters. Unknown media types are allowed; the declaration implies no decoding or execution.                                    |
| File `sha256`    | SHA-256 of the original uncompressed bytes, encoded as 64 lowercase hexadecimal characters.                                                                                           |

Only these fields are required. There are no required package categories or
per-file IDs. Byte sizes come from the checked ZIP records; they are not duplicated
in the manifest. Top-level `metadata` and `extensions`, and file-level `metadata`,
are optional JSON objects. Use namespaced keys for application-owned extensions.
Core objects reject unknown properties; application-specific descriptions belong
in these optional objects.

A file may optionally include `tags`. Every field inside it is optional:
`energy` (`low`, `medium`, `high`), `tension` (`calm`, `suspenseful`, `urgent`),
`tone` (`bright`, `neutral`, `dark`), and `descriptive` (up to 64 distinct nonblank
strings, each at most 128 characters). These retain their value checks when
supplied and are never universal content requirements.

### Creator defaults and identity

Users enter a name, description, and files. For a new package, the reference
creator generates a UUID using `crypto.randomUUID()`, defaults the package
version to `1.0.0` and publisher to `SEIHouse Productions LLC`, and generates the
current UTC timestamp. It infers common media types (unknown extensions default
to `application/octet-stream`), inventories the files, and hashes their bytes.
API callers may override the ID, package version, publisher, timestamp, and media
types. The format version and file hashes are always generated by the builder.

For a later release of the same package, retain the original `id` and assign a
new package `version`. Changing name, contents, timestamps, or hashes never
implies a new identity. The host keeps the ID in its existing package record and
passes it to `createPack`; a non-default version without an ID is rejected.
The playground's explicit update action retains ID and publisher and increments
the patch version, dropping any prerelease/build suffix. Its new-package action
generates a separate identity. Re-saving unchanged bytes retains the manifest.
There is no global registry: an isolated package cannot prove version history,
ID uniqueness, or publisher ownership.

### Version boundary

This contract replaces the earlier 0.1 manifest (`format`, `packType`, `assets`,
per-file IDs and sizes). The 1.0 reader reports `UNSUPPORTED_VERSION` for 0.1 and
unknown versions. It preserves diagnostic inspection where possible but blocks
asset access. No silent migration or dual interpretation is performed. Hosts
using the former `assets` creation input or inspection inventory must use `files`;
`content.assets` remains the adapter's path-to-bytes map.

## Portable paths and duplicates

Paths use `/`, begin with `assets/`, and contain only ASCII letters, digits,
spaces, `_`, `-`, `.`, `(`, and `)` within segments. Limit the entire path to
240 characters. The display names and descriptions in metadata may use Unicode.
Each segment must be nonempty, cannot be `.` or `..`, and cannot begin or end
with a space or period. Reject Windows device names `CON`, `PRN`, `AUX`, `NUL`,
`COM0`–`COM9`, and `LPT0`–`LPT9`, including names with an extension, ignoring case.

No absolute paths, backslashes, drive prefixes, colon streams, encoded paths,
control characters, links, or special files. Treat internal paths as literal
strings: never URL-decode them or resolve parent references. Reject case-insensitive
path collisions and file/folder conflicts, including `assets/a` plus `assets/a/b`.
These conservative rules avoid different extraction meanings across operating systems.

Duplicate manifest paths, and raw ZIP filenames are errors. Duplicate byte
content at distinct paths is detected as a warning; it is permitted because
two intentional assets can contain the same bytes. A warning does not block extraction.

## Supported ZIP profile

Use classic, single-disk ZIP with methods 0 (stored) or 8 (raw DEFLATE). Writers in
this skeleton use stored entries to favor predictability over compression. CRC-32
must match the uncompressed bytes. ZIP version-needed must not exceed 2.0. Allow
only the UTF-8 flag (bit 11) and DEFLATE option flags (bits 1 and 2). ASCII filenames
are identical whether or not the UTF-8 flag is present.

No encryption, ZIP64, multi-volume archives, data descriptors, extra fields, archive
comments, per-file comments, directory entries, symlinks, or other special file
attributes. Unknown methods or flags are unsupported. Unix mode type must be
unspecified or regular file. DOS directory and volume-label bits must be clear.

Local and central headers must agree on filename, flags, version-needed, method,
CRC, and compressed/uncompressed sizes. File ranges must be contiguous, cannot
overlap, and must end at the central directory. The directory must end exactly
at the 22-byte end-of-central-directory record. Reject unlisted records, prefixes,
trailing container bytes, conflicting disk counts, and out-of-bounds offsets.
The file name extension alone is never evidence of validity.

This deliberately small profile means some general-purpose ZIP tools produce
unsupported packs unless configured. Python's `zipfile.ZipFile` writing to a
seekable file with default metadata and ZIP_STORED or ZIP_DEFLATED can produce
compatible containers. The checked-in interoperability script demonstrates this.

## Validation and resource limits

Apply these ceilings before copying or expanding archive content:

| Limit                               | Default hard ceiling             |
| ----------------------------------- | -------------------------------- |
| Input archive bytes                 | 64 MiB (67,108,864 bytes)        |
| Entries, including manifest         | 1024                             |
| Expanded bytes in one file          | 32 MiB (33,554,432 bytes)        |
| Total expanded bytes                | 128 MiB (134,217,728 bytes)      |
| Expanded manifest bytes             | 1 MiB (1,048,576 bytes)          |
| Expanded/compressed ratio, per file | 200, with denominator at least 1 |

Callers may lower these ceilings, using positive integers. Raising ceilings
requires a future deliberate implementation decision. Also enforce actual
decompression output against declared size while inflating, not only before it.
The TypeScript inflater receives compressed data in 1 KiB chunks and aborts when
emitted bytes exceed the declared size. It does not allocate based on an unbounded
untrusted size. It retains bounded in-memory data and is not a large-media streaming
solution. Peak memory includes input, expanded files, inflater buffers, and output
copies requested by the caller; it is higher than the largest individual ceiling.

Recommended validation order:

1. Bound input size; parse the ZIP directory and local headers with bounds checks.
2. Reject unsupported ZIP features, unsafe or duplicate paths, and oversized claims.
3. Expand files within budgets and verify each ZIP CRC-32 and actual byte size.
4. Parse the manifest with UTF-8, duplicate-key, depth, and JSON Schema checks.
5. Check unique paths and exact correspondence between records and ZIP files.
6. Compare each file's SHA-256 with its manifest record.
7. Report every recoverable problem. Structural failures may prevent further inspection.
8. Permit extraction only if there are zero errors. Warnings remain visible.

Changing an asset while leaving its manifest unchanged causes a fingerprint error.
Damaged raw ZIP bytes may cause a CRC, decompression, or structural error first.
SHA-256 is an integrity fingerprint, not a signature: someone able to replace both
an asset and its manifest can make a different valid pack. This format does not
establish trust, authorship, provenance, or safe execution of asset contents.

## Extraction contract

The universal API returns only verified asset bytes in a new path-to-bytes map.
Returned inspection objects and file bytes are copies; modifying them cannot
change a previously opened pack's internal validation state. Invalid packs remain
inspectable when enough structure survives, but cannot expose extractable assets.

The Node adapter validates before any write, resolves the existing destination
parent, and exclusively creates a new private output directory. It refuses an
existing output path, including a symlink or junction, creates regular files with
exclusive writes, and removes its newly created directory if a write fails. It
never merges into an existing folder or restores archive permissions.

The caller must control the destination parent directory. Protection against a
different process with the same filesystem privileges actively replacing freshly
created paths during extraction is outside this portable adapter's contract.
Large or hostile workloads should run with lower limits and process isolation.
Consumers decide how to view assets; loading a pack never executes an asset.

## Deliberately open

Optional metadata and namespaced extensions leave application meaning to the
receiving host. This version defines no installation, storage, AI classification,
playback, marketplace, signing, or application-specific contracts.

ZIP reference: [PKWARE ZIP Application Note](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT).
Schema dialect: [JSON Schema draft 7](https://json-schema.org/draft-07).
