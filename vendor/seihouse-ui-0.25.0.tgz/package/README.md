# @seihouse/ui

Reusable SEIHouse React components, interaction contracts, and design tokens.

**0.24.0 (2026-11-16):** Adds **A Sword Opens the World**, the first official
NovelExpanded search animation. Import `novelExpandedSearchDecoration` from
`@seihouse/ui/search-scenes/novel-expanded` and pass it to `SEISearchBar`.
Original SVG mountains, mist, a flying sword and gold Qi follow one 4.8-second
choreography, then settle into a quiet landscape. The dedicated entry is opt-in;
the scene stays visible and playing during focus and typing. The engine skips
artwork-transform timelines identical to the resting pose. See
[the scene and creative brief](./SEARCH_CHOREOGRAPHY.md#novelexpanded-a-sword-opens-the-world).

**0.23.0 (2026-11-16):** Adds `SEISearchBar`, a shared native search input or
search-dialog trigger composed from `SEIInput`/`SEIButton`, with an optional
choreography stage. `defineSEISearchChoreography` and
`validateSEISearchChoreography` support versioned, bounded, agent-authored recipes;
hosts supply static artwork and retain search behavior and scene selection.
Playback is finite, pauses during interaction/offscreen, respects reduced motion,
and cleans up on replacement/unmount. No default or seasonal animation is shipped.
See [Search choreography](./SEARCH_CHOREOGRAPHY.md) for the public contract,
host examples, authoring workflow, and limits.

**0.20.1:** Preserves `openPlugin={null}` as a controlled closed state in `SPPPluginBrowser` and fixes the `defaultOpenPackage` legacy fallback when `defaultOpenPlugin` is omitted.

**0.20.0:** Renames the SPP plugin components and catalog terms to `SPPPluginCard`,
`SPPPluginShelf`, `SPPPluginRail`, `SPPPluginDetail`, `SPPPluginBrowser`, and
`SPPPluginLoadout` (replacing "package" / "packages" in UI copy and adding
`pluginId`, `plugins`, `onOpenPlugin`, `openPlugin`, `onAddPlugin`, and `onRemovePlugin`
props). Deprecated `PackageCard`, `PackageShelf`, `PackageRail`, `PackageDetail`,
`PackageBrowser`, and `PluginLoadout` aliases and legacy `Package*` props remain
exported for compatibility.

**0.19.0:** Adds `PluginLoadout`, the page that shows what a project runs on, one
slot per row. A switch at the top picks the part (for example Story, Blueprint, Tagger);
each row shows a slot, the plugin in it and its version as a badge. Slots sit under
Information, Media (`kind: "media"`, in their own colour) and Automatic. Tapping a row opens that slot's page, the way
a phone's settings do: the installed plugins that fit, a check on the one in use, "None"
unless the slot is `required`, and an upload row. Choosing one calls `onEquip` and comes
back. A slot with `mode: "auto"` shows only what is loaded; its page says what decides it
(`autoSummary`). On a wide screen the list and the slot's page sit side by side. Pass
`groups`, `slots` and `options`; group and open slot can each be controlled. The host
handles uploads through `onUpload` or `renderUpload` and never hands files to the
component.

**0.18.0:** Removes `ElementalTitle` and its `ElementalTitle*` types, along with
`elemental-title.css`. Elemental Title now lives in the font lab as its own package; import
it from there. Nothing else changes: no other component, prop or stylesheet is affected.

**0.14.0:** Adds `PackageShelf`, the holder for many packages. It lays `PackageCard`s out
as a grid or a list with a view switch and a count, and covers loading, empty, a failed
load, and adding a package by button or by drop. Pass `packages` (each is the card's props
plus an `id`), and wire `onOpenPackage`, `onAddFiles`, and `onRetry` as needed. The shelf
hands picked or dropped `File`s to the host and never reads them. It sizes its columns from
its own width through a CSS container query.

0.14.0 also adds the catalog page built on the shelf. `PackageBrowser` shows a catalog as
one sideways row per category, with search, a group switch (for example All, Media,
Information), a Mine toggle, "See all" into the full shelf, and a package detail in a
drawer. Pass `groups`, `categories` and `packages` (each package names its `category` and
whether it is `added`), and wire `onAddPackage` and `onRemovePackage`. Group, category,
open package, search and Mine can each be controlled, so an app can open the page on one
category. Its parts are exported on their own: `PackageRail` (one category row),
`PackageDetail` (one opened package) and `SEISegmentedControl` (a single-choice radio
group for a view or a filter).

**0.13.0:** Adds `PackageCard`, how an SPP package looks inside an app, in `tile`,
`row`, and `hero` sizes. Only `name` is required. A package without a cover, or whose
cover fails to load, shows a cover generated from its `packageId`. The card is
presentational: the host opens and validates the package, passes `coverSrc` (an object
URL for an embedded cover or an `https` link) and `integrity`, and wires `onOpen`. The card lays
itself out from its own width through a CSS container query, so place it in a grid cell or
a sized wrapper.

**0.12.0:** Adds `SEIColorField`, `SEIColorSwatchGroup`, `SEISelectionBar`,
`SEIInlineEdit`, and opt-in measured rows for `SEIVirtualScrollArea`. The fixed-height
virtualization contract remains the default. TanStack Virtual is a pinned runtime
dependency of the package; consumers do not need to install it separately.

**0.11.0 (2026-10-06):** `SEIAppShell` and Pathways navigation panels accept
`sidebarBehavior="double-tap"`: two taps/clicks within 350ms and 24px toggle
expanded (`pinned`) and compact width. Single taps still navigate; scrolling,
dragging and canceled pointers clear the gesture. Hover and focus keep the width.
A minimize/expand button appears on keyboard focus. Existing `automatic` and
`click` behavior is unchanged; preference persistence belongs to the host.

Install the package and its required React peers:

```bash
npm install @seihouse/ui react react-dom
```

The package is ESM-only. Its `prepack` lifecycle builds JavaScript, declarations,
and CSS from source. Releases are published from the repository's manual GitHub
Actions workflow using npm trusted publishing.

```tsx
import { SEIButton } from "@seihouse/ui";
```

In the host Tailwind v4 stylesheet:

```css
@import "tailwindcss";
@import "@seihouse/ui/styles.css";
```

`styles.css` includes tokens and the component stylesheets, and registers the
shipped JavaScript as a Tailwind source, including variant/focus/responsive classes. It does not include a second
Tailwind preflight. `@seihouse/ui/tokens.css` exports tokens alone for hosts that
manage class generation themselves. CSS files are marked as side effects.
Only the root JS API and these two CSS exports are supported; no private deep imports.
React 19 and the listed peers must resolve without `--legacy-peer-deps` or `--force`.

The workbench and Storybook intentionally alias the root API to source for HMR;
external consumers resolve only built files. Components are not copied into apps.

The experience contract is exactly `default`, `sea`, and `sen`. Set
`data-experience="sea" data-theme="dark"` on the document element for music
products, including portal-based overlays. `data-theme` independently selects
dark or light contrast. Use shared semantic tokens for colors, typography,
fields and glass treatments.

Version 0.3.0 narrows the public experience contract; consumers must select one
of these three values and use the shared tokens before upgrading.

## Versioning policy

`packages/seihouse-ui/package.json` is the source of the version published to npm
and used by consuming apps to identify the package copy. A change to runtime
behavior, public props or types, generated styles, or the package dependency
contract must bump this version in the same pull request. The pull request
workflow checks for a bump whenever publishable package files change, excluding
tests and documentation. Before `1.0.0`, use a patch for compatible fixes and a
minor version for new or breaking contracts. After `1.0.0`, use patch for
compatible fixes, minor for additive APIs, and major for breaking changes.

## Switch (0.17.0)

`SEISwitch` renders a React Aria binary setting. `size` is `"comfortable"`
(default, 44 × 24px track) or `"compact"` (36 × 20px track) at a 16px root.
Track, thumb, padding and travel scale together when the root font size changes.
Both reserve a 2.75rem touch target on mobile (44px at a 16px root).
Space toggles the focused input; reduced motion
suppresses thumb animation, and a system outline preserves focus in forced colors.

```tsx
<SEISwitch defaultSelected onChange={setEnabled}>Enable playback</SEISwitch>
<SEISwitch size="compact" isSelected={enabled} onChange={setEnabled}>
  {({ isSelected }) => `Playback ${isSelected ? "on" : "off"}`}
</SEISwitch>
<SEISwitch aria-label="Enable playback" isDisabled />
<span id="playback-label">Enable playback</span>
<SEISwitch aria-labelledby="playback-label" />
```

Provide meaningful visible `children`, `aria-label`, or `aria-labelledby`.
**Migration from 0.16:** a label source is now required by `SEISwitchProps`;
missing, empty and whitespace-only labels also throw at render time unless an
explicit ARIA name is supplied. Function children receive React Aria's switch
render state, including `isSelected`, `isDisabled`, and `isFocusVisible`.
Hosts must ensure custom label components produce meaningful text and that
`aria-labelledby` references an existing, nonempty label.

React Aria props pass through: use `isSelected` / `onChange` for controlled state,
`defaultSelected` for uncontrolled state, `isDisabled` to prevent interaction,
and `name` / `value` for form submission. `className` styles the outer label.
Hosts own persistence. The off fill uses `--sh-control-track`, distinct from
`--sh-progress-track`; light field borders use the experience field tokens.
These styles and types are prepared for 0.17.0; npm publishing is separate.

## Studio primitives (0.12.0)

All components and their prop types are exported from `@seihouse/ui`.

### Color controls

`SEIColorField` combines a native color picker with a labeled hex text field.
It accepts opaque three- or six-digit hex, with or without `#`, and commits
uppercase `#RRGGBB` through `onValueChange`. Partial text remains a local draft;
Enter or blur commits a valid value, Escape restores the current color, and an
invalid commit exposes an accessible error. Alpha, CSS names and CSS functions
are outside this version's contract. `normalizeHexColor` exposes the same parser.

```tsx
<SEIColorField label="Accent" value={color} onValueChange={setColor} name="accent" />
<SEIColorSwatchGroup
  label="Presets"
  options={[{ label: "Ocean", value: "#0068D1" }, { label: "Forest", value: "#16734B" }]}
  value={color}
  onValueChange={setColor}
/>
```

Both controls support `defaultValue`, `disabled` and native form submission via
`name`. Use valid hex values for controlled/default colors. The field supports
`helperText`, host `error`, and a configurable `invalidMessage`. The swatch group
uses labeled native radios with arrow-key navigation; each option must have a
unique normalized color and can be disabled individually. Invalid options are
disabled. Hosts own palette definitions and persistence.

### Selection bar

```tsx
<SEISelectionBar
  selectedCount={selectedIds.length}
  totalCount={eligibleItems.length}
  onSelectAllChange={(all) => setSelectedIds(all ? eligibleItems.map((item) => item.id) : [])}
  onClear={() => setSelectedIds([])}
  placement="inline"
>
  <SEIButton disabled={!selectedIds.length} onClick={exportSelected}>
    Export selected
  </SEIButton>
</SEISelectionBar>
```

The host supplies counts from the same eligible collection and owns selection,
filtering and action behavior. The bar exposes a mixed-state select-all checkbox,
a polite count announcement, optional clear action, and an action slot. It remains
visible at zero selection; actions should set their own zero-selection disabled
state. `placement="floating"` positions it above the viewport's safe-area bottom;
reserve space in the host so it does not cover content. The floating surface is
height-bounded and scrolls internally on short screens. Labels and action buttons
wrap without reducing their touch targets. `disabled` disables the
checkbox, clear button and native form controls in the action fieldset. Host links
or custom non-form actions must handle their own disabled behavior. Labels and
`formatCount(selected, total)` are customizable. The bar does not trap focus.

### Inline edit

```tsx
<SEIInlineEdit
  label="Title"
  value={title}
  validate={(draft) => (draft.trim() ? undefined : "A title is required.")}
  onSave={async (draft) => {
    await persistTitle(draft);
    setTitle(draft);
  }}
/>
```

The controlled value is copied into a draft when editing begins. Enter saves,
Escape or Cancel discards the draft, and IME composition does not submit. Saving
can be asynchronous: controls prevent duplicate submissions, a rejected promise
keeps the draft with an error, and successful keyboard/button commits restore
focus unless the user has moved elsewhere. No parent form is submitted.
`commitOnBlur` is opt-in and runs only when focus leaves the entire editor;
Save/Cancel clicks inside it are not outside commits. Validation is synchronous;
provide `saveErrorMessage` for localized server-failure feedback. The host must
update `value` after a successful save and own normalization/persistence. External
value changes do not overwrite a draft while it is being edited.

### Variable-height lists

```tsx
const listRef = useRef<SEIVirtualScrollAreaHandle>(null);

<SEIVirtualScrollArea
  items={assets}
  itemHeight={100}
  measureItems
  getItemKey={(asset) => asset.id}
  maxHeight="24rem"
  gap={12}
  handleRef={listRef}
  label="Assets"
  renderItem={(asset) => <AssetCard asset={asset} />}
/>;
// listRef.current?.scrollToIndex(149, "start");
// listRef.current?.scrollToTop();
```

`measureItems` opts into ResizeObserver-driven row measurement. `itemHeight` is
then an estimate for unseen rows; `gap` adds spacing without external row margins.
Expansion and responsive text wrapping update offsets. A stable `getItemKey` is
required for collections that reorder/filter; keep the resolver function stable
when possible to avoid invalidating the engine cache on unrelated host updates. Index keys are suitable only for
immutable order. Keep editable data and expanded state in the host keyed by item
ID, because offscreen rows unmount. The currently focused row stays mounted while
scrolling and reordering, but removing that item still removes its focused control.
Viewport width changes invalidate cached heights. Navigation uses immediate
scrolling; unseen rows settle as their actual heights become known.

To share an existing scrolling element, pass its `scrollRef` and `scrollMargin`
(the list's offset from that container's content origin, including any header).
The host owns that container's size, overflow, events and accessible name. Update
`scrollMargin` when preceding content changes height. `maxHeight` and the overlay
scrollbar apply only to the internally owned viewport. `scrollToTop()` scrolls to
the list's start, including its margin. `handleRef`, `gap`, `scrollRef` and
`scrollMargin` are measured-mode options. Omitting `measureItems` retains the
existing fixed-height implementation and `getVirtualRange` behavior.

## Product presentation layers (0.4.0)

`SEIButton`, `SEIPanel`, `SEICard`, `SEIInput`, `SEITextarea`,
`SEIBottomNavigation` and `SEIDrawerContent` accept `unstyled` for a
product-owned skin. The caller supplies
focus styling when opting out of the default skin, except bottom navigation,
which always keeps shared themed keyboard focus; native/keyboard/modal
behavior remains canonical. `SEICard.renderContent` replaces its convenience
slot composition. `SEIButton` additionally accepts `iconSize` and
`loadingIndicator`; bottom navigation accepts `showLabels` (default true).
These are generic extension points; the SEN layer in `src/sen` (`@seihouse/ui/sen`, see [SEN.md](./SEN.md))
composes them without creating a reverse dependency.

## Skins

A skin restyles a universal component inside one `data-experience` without a
second component. `SEIPanel` and `SEICard` read `--sei-panel-*` and
`--sei-card-*` slots (declared in `skin-slots.css`, shipped with `styles.css`)
with their experience tokens as the fallback, so an empty slot changes nothing.
A skin stylesheet fills the slots in `@layer components`, keyed off the
`data-surface` and `data-variant` markers the components emit; utilities a host
passes in still win. The SEN skin is described in [SEN.md](./SEN.md).

`SEIPanel` gains `callout` and `footer` variants and `SEICard` gains `callout`.

## Bottom navigation

`SEIBottomNavigation` owns both `variant="bar"` (default) and `variant="dock"`
(an inset, floating surface). Both use the same sticky placement, safe-area
padding, 52px minimum tab height, 12px labels, `aria-current="page"`, selection
callbacks and optional visually hidden labels (`showLabels={false}`). Full
labels remain the accessible names and are available as native button titles
when the visible text truncates.

The public React 19 `ref` points to the `<nav>`, including all safe-area padding.
Hosts that overlay a dock can observe its actual height rather than guess:

```tsx
import { useEffect, useRef, useState } from "react";
import { SEIBottomNavigation } from "@seihouse/ui";

function DockPage() {
  const navigationRef = useRef<HTMLElement>(null);
  const [navigationHeight, setNavigationHeight] = useState(0);

  useEffect(() => {
    const navigation = navigationRef.current;
    if (!navigation) return;
    const measure = () => setNavigationHeight(navigation.getBoundingClientRect().height);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(navigation);
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <div style={{ paddingBottom: navigationHeight }}>Page content</div>
      <SEIBottomNavigation
        ref={navigationRef}
        aria-label="Primary"
        variant="dock"
        className="fixed bottom-0"
        items={destinations}
      />
    </>
  );
}
```

A flex/grid footer outside the scrolling region already reserves its own space.

The public slots are `bottom-navigation`, `bottom-nav-tabs`, `bottom-nav-tab`,
`bottom-nav-icon` and `bottom-nav-label`. A product skin can select the dock
layout and set `--sei-bottom-nav-*` surface, state and typography properties on
the nav. The shared stylesheet paints one surface and owns all state selectors.
Focus uses `--sh-focus-ring` / `--sh-focus-offset` even with `unstyled`;
High Contrast uses a `Highlight` outline and an underlined, bordered selected
item. Reduced transparency uses the opaque surface token and disables both
prefixed and unprefixed backdrop filters. Without backdrop-filter support the
surface is opaque by default. Skins should set `--sei-bottom-nav-opaque` to an
opaque color alongside their translucent `--sei-bottom-nav-fill`.

## Badge

`SEIBadge` is a static status label. It supports a bounded long label with
`truncate`, and an optional trailing decoration with `iconRight`. Import it from
the package root; the packed JavaScript and Tailwind source registration include
the badge styles.

```tsx
import { SEIBadge } from "@seihouse/ui";

<SEIBadge variant="info" truncate>
  Chapter 12 · Draft
</SEIBadge>;
```

Give a truncated badge a width constraint through its flex/grid track or parent.

## Header components — which one is which

Three components carry "header" in their name and they are not interchangeable.

| Component       | Role                                                                                 | Outline                              |
| --------------- | ------------------------------------------------------------------------------------ | ------------------------------------ |
| `SEIHeader`     | Heading block that opens a section of content: eyebrow, title, description, actions. | Renders a heading (`h2` by default). |
| `SEIPageHeader` | The same block at the top of a page, plus an optional breadcrumb.                    | Owns the page's `h1`.                |
| `SEIAppHeader`  | Persistent application chrome above both of them.                                    | Renders **no heading at all**.       |

`SEIAppHeader` is the top-level header of a focused SEIHouse application. It
stays put while the page underneath changes and answers three questions at
once: which app am I in, where am I inside it, and who am I signed in as. It
carries a branding slot, the app name, an optional contextual/page label, an
optional mobile navigation trigger, an actions slot, and a profile/account slot.

Because it is chrome rather than content, the app name is deliberately a
`<span>`: promoting it would place a competing top-level heading above every
page's own `SEIPageHeader`. Landmarks are explicit for the same reason —
`landmark="banner"` (the default) renders a real `<header>`, and
`landmark="none"` renders a plain `<div>` for hosts that already own the
`<header>`, `SEIAppShell`'s `header` slot being the usual case, so a page never
ends up with a header nested inside a header.

```tsx
<SEIAppShell
  header={
    <SEIAppHeader
      landmark="none"
      appName="SEA Console"
      branding={<SeaMark aria-hidden />}
      contextLabel="Vault"
      navigationTrigger={<MenuButton onClick={openDrawer} aria-expanded={open} />}
      actions={<SearchButton onClick={openSearch} />}
      profile={<AccountButton onClick={openAccount} />}
      onBrandSelect={() => router.push("/")}
    />
  }
>
  <SEIPageHeader title="Recovered fragments" />
</SEIAppShell>
```

Layout contract: the identity group is the flexible column and truncates first,
so a long app or context name shortens rather than pushing the account button
off a phone screen. The bar never reflows to a second row — a growing header
would shift the page beneath it — so hosts with more actions than fit a narrow
viewport collapse them into an overflow menu in the `actions` slot. The context
label stays in the accessibility tree at every width but is only painted from
`sm` up, and the navigation trigger retires at `md` unless
`navigationTriggerVisibility="always"`.

Routing, authentication, account logic, and navigation state stay outside. The
only control the component renders itself is the optional brand button, which
reports intent through `onBrandSelect`.

## App Shell integration

### Automatic Pathways rail (0.9.0)

The optional mode API lets each host expose its own sidebar preferences without
putting storage, routing, or settings UI in the component package:

```tsx
<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  sidebarMode={savedSidebarMode ?? "automatic"}
  onSidebarModeChange={saveSidebarMode}
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio"
      variant="pathways"
      sections={sections}
      account={account}
    />
  }
>
  {page}
</SEIAppShell>
```

`SEISidebarMode` is `"automatic" | "pinned" | "compact"`. Automatic starts as a
compact rail, opens while a mouse/pen is near the sidebar or keyboard focus is
inside it, and closes when neither remains. The expanded panel has a 44px star
button: **Pin sidebar open** locks it open; **Unpin sidebar** returns to
automatic. `"compact"` is a host-selectable compact-only setting and suppresses
the pin. `sidebarMode` is controlled; use `defaultSidebarMode` for shell-owned
UI state. `onSidebarModeChange` reports pin/unpin requests only, so transient
hover never overwrites a saved preference. The same three props work on a
standalone Pathways panel. Mode props take precedence over the older boolean
collapse props when both are supplied. Without any mode or collapse props,
existing shell consumers keep their expanded sidebar and default panel styling.
The phone/tablet drawer keeps its current behavior.

The shell continues to animate the column width, except under reduced motion.
The host may render its own advanced settings for these three modes and persist
the selected mode per device or account. The UI package never stores it.

### Pathways refinements (0.8.0)

`SEIAppShell` can now coordinate a Pathways panel without a second host state:

```tsx
<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  defaultSidebarCollapsed={savedDevicePreference}
  onSidebarCollapsedChange={saveDevicePreference}
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio"
      variant="pathways"
      account={account}
      sections={sections}
    />
  }
  header={
    <SEIAppHeader
      landmark="none"
      appName="Studio"
      branding={logo}
      center={insights}
      actions={actions}
    />
  }
>
  {page}
</SEIAppShell>
```

`sidebarCollapsed` makes the shell controlled; otherwise it starts from
`defaultSidebarCollapsed` (false when omitted) and reports toggles through
`onSidebarCollapsedChange`. The shell stores only current UI state, never a
persistent preference. When collapse is enabled, the panel inherits it and
switches between full Pathways and compact density. A standalone panel may use
`collapsed` and `onCollapsedChange` directly. The toggle is a named 44px button
beside the top account/identity spot; it appears on hover or keyboard focus and
remains visible on non-hover devices. The width transition stops for reduced
motion. These props are optional; the existing 16rem shell sidebar and default
panel appearance remain the same without them.

Pathways `account` takes the top identity spot when both are supplied. Its
`name` and optional rank/detail remain the compact accessible name and tooltip;
`account.onSelect` makes the whole card actionable. `identity` remains the
fallback. A host may pass a signed-out avatar and `name: "Sign in"` through the
same slot. The default variant retains its previous account header.

Pathways shows children only under an active parent. They use smaller unbadged
icons and a separate active accent, configured with
`--sh-nav-child-active-accent`, `--sh-nav-child-active-glow`, and
`--sh-nav-child-active-text`; the default variant retains its existing child
visibility. The items scroller uses the shared overlay scrollbar described below.
Its conditional top/bottom fades mark hidden content; wheel, touch and keyboard
scrolling remain native.
Long Pathways labels use up to two lines and retain a full-label tooltip; section
guidance wraps inside its card.

`SEIAppHeader.center` accepts host content between identity and actions.
`centerBreakpoint` is `"lg"` by default and also accepts `"md"`, `"xl"`, or
`"always"`; `centerClassName` customizes the slot. The center remains at the
header midpoint and shrinks before side content. Content hidden below its
breakpoint is removed from layout and keyboard focus.

### Pathways sidebar (0.7.0)

`SEINavigationDrawerPanel` is the universal sidebar and drawer-content renderer.
Opt into `variant="pathways"` for tall pills, round icon wells and theme-driven
active/focus states. With no new props, its existing account/sections/actions
presentation is unchanged. `SEINavigationDrawer` forwards the same options.

```tsx
import { SEIAppShell, SEINavigationDrawerPanel } from "@seihouse/ui";

<SEIAppShell
  sidebarBreakpoint="lg"
  sidebarWidth="14rem"
  sidebar={
    <SEINavigationDrawerPanel
      aria-label="Studio navigation"
      variant="pathways"
      identity={{
        name: "Studio",
        emblem: { src: studioEmblemUrl, alt: "Studio emblem" },
        divider: true,
      }}
      sections={[
        {
          id: "workspace",
          label: "Workspace",
          items: [
            { id: "home", label: "Home", icon: homeIcon, active: true, href: "/" },
            {
              id: "projects",
              label: "Projects",
              icon: projectsIcon,
              onSelect,
              children: [{ id: "drafts", label: "Drafts", icon: draftsIcon, onSelect }],
            },
          ],
        },
      ]}
      artwork={{ type: "image", src: landscapeUrl }}
      footer={{
        divider: true,
        items: [{ id: "support", label: "Support", icon: supportIcon, href: "/support" }],
        content: <small>Workspace status supplied by the host</small>,
      }}
    />
  }
>
  {routeContent}
</SEIAppShell>;
```

All example URLs, icons, handlers and route content come from the host. The
package bundles no emblem, artwork, app names, destination lists or remote fonts.

- `identity`: accessible `name`, optional visual `wordmark`, `emblem: { src, alt }`
  and `divider` (`true` for a line, or a decorative node between lines).
- Items retain `id`, `label`, `icon`, `active`, and `onSelect(id)`. Optional `href`
  uses a native link; `onSelect` also observes activation without preventing it.
  `children` is one level deep, with independent current-page states. `required`
  and non-interactive `trailing` content preserve status announcements.
- Sections also accept `icon`, `tagline`, and guidance in `footer`. Section
  guidance scrolls with its destinations.
- Panel `footer` accepts arbitrary `items`, custom `content`, and optional
  `divider`. Legacy `actions` remain supported and render before this footer
  when both are present. An empty footer produces no wrapper or divider.
- `artwork` is `{ type: "image", src }` or `{ type: "video", src, poster? }`.
  Both are decorative. Video is muted, inline, looping and autoplaying, without
  controls. Server rendering and reduced motion use the poster; without a poster
  they use the panel surface. Changing the preference removes the playing video.
- `density="compact"` opts into a named icon rail. Pair it with
  `sidebarWidth="4.5rem"`; density does not resize the host shell. Children remain
  directly reachable below their parent. Missing icons use initials. Every
  built-in control has a focus/hover tooltip; required and trailing text remains
  accessible. Custom footer nodes are host-owned and must fit the compact width.
- `account` remains available alongside identity and gains optional `eyebrow`.
  `closeLabel` defaults to `Close navigation`.
- The modal wrapper's optional `mobileOnly` defaults to false. When true it
  suppresses the modal at 1024px and releases focus and scroll lock. Match a host
  using that mode with `sidebarBreakpoint="lg"`. `side` remains left/right.

The panel fills its bounded parent. Identity/profile and footer do not scroll;
only destinations scroll. Decorative artwork yields space first, shrinks below
800px, and hides at 650px or less (both panel and viewport height). Without
artwork, remaining space still separates navigation from the footer. Keep custom
identity/footer content small enough to leave room for destinations.

Pathways uses `--sh-nav-*` custom properties with neutral semantic defaults:
`surface`, `text`, `muted`, `font`, `identity`, `divider`, `hover`, `selected`,
`selected-text`, `accent`, `focus`, `active-border`, `active-shadow`, `active-icon`,
`icon-border`, `icon-surface`, `row-height`, `icon-size`, `radius`, `gap`, and
`artwork-opacity`. Set overrides on the panel using `style`, or a theme rule
targeting `[data-slot="navigation-panel"]`. Keep row targets at least 44px.
Forced colors preserves outlines and selection independently of artwork/glow.

Product skins can use `unstyled`, `classNames`, `closeButton`, `surfaceProps`,
and `panelClassName` without replacing rendering or modal behavior. The optional
`classNames.tooltipPositioner` controls portaled tooltip stacking for hosts with
a custom modal layer. `closeButton` receives the shared handler and close label.
`surfaceProps` is a drawer-surface hook; panel props remain on the panel.

Workbench: Navigation Drawer includes image, video, no-artwork, compact and short
variants. App Shell includes Pathways with a live `sidebarBreakpoint` control.

`SEIAppShell` owns the outer app layout: it renders one `<main>` landmark, keeps
the header and optional footer in place, and scrolls long main and sidebar
content inside the available height. Put the route view directly inside the
shell; do not add another `<main>` around it. Give `mainId` a page-unique value
and place a skip link before the shell so keyboard users can jump to that
region:

```tsx
import { useRef } from "react";
import { SEIAppHeader, SEIAppShell, SEIBottomNavigation } from "@seihouse/ui";

function AppLayout() {
  const mainRef = useRef<HTMLElement>(null);

  return (
    <>
      <a className="sr-only focus:not-sr-only" href="#app-main">
        Skip to main content
      </a>
      <SEIAppShell
        mainRef={mainRef}
        mainId="app-main"
        sidebarBreakpoint="lg"
        header={<SEIAppHeader landmark="none" appName="SEA Console" />}
        sidebar={<nav aria-label="Primary">{/* Host-owned links shown at lg+ */}</nav>}
        footerClassName="lg:hidden"
        footer={<SEIBottomNavigation aria-label="Primary" items={mobileDestinations} />}
      >
        <RouteView />
      </SEIAppShell>
    </>
  );
}
```

The shell fills `100dvh` by default and assumes a viewport-contained app with
internal scrolling. To place it inside a bounded host panel instead, give the
parent an explicit height and use `className="h-full min-h-0"` on the shell.
Keep the host's flex/grid ancestors shrinkable (`min-h-0`) as well. For a
document-scrolling page, use the page/layout primitives rather than this app
shell contract. `mainRef` points at the scrollable `<main>` element; the
component's forwarded `ref` continues to point at the outer shell `<div>`.

## File Upload and folder import

`SEIFileUpload` keeps the regular file picker and adds a separately named folder
picker when `allowDirectory` is set. It also recursively reads folders dropped
onto the drop area where the browser exposes directory entries. Folder files
pass through the same accept, size, count, and custom validation as regular
files. Directory selection enables multiple files and preserves browser-provided
`File.webkitRelativePath` values on the `File` objects sent to `onFilesChange`.
Files from a dropped folder carry the same `Folder/sub/file` relative paths,
restored from the dropped directory entries; loose dropped files keep an empty
path, as the regular file picker reports them.
Upload, storage, and folder processing remain host responsibilities.

```tsx
<SEIFileUpload
  allowDirectory
  accept="audio/*"
  maxFiles={250}
  onFilesChange={(files) => queueFiles(files)}
/>
```

The `sidebar` defaults to appearing at `md`; set `sidebarBreakpoint` to `"lg"`
or `"xl"` to delay it. The selected breakpoint controls both sidebar visibility
and the grid column, while the shell leaves responsive navigation to the host.
The host owns route state, the active item, and an alternate mobile drawer or
bottom navigation. If both desktop and mobile navigation are present, give each
landmark an accessible label and hide the inactive one at the same breakpoint.
The `header` slot is already wrapped in a `<header>`, so use
`SEIAppHeader landmark="none"` there.
The optional `footer` is a separate, non-scrolling row; keep its content short
and account for device safe areas with `SEISafeArea` or a navigation component
that already pads for the home indicator. Use `footerClassName` when the whole
row is breakpoint-specific, such as a mobile-only bottom navigation, so the
hidden footer does not leave an empty grid row or border at wider sizes.

Import `@seihouse/ui/styles.css` from the host's Tailwind v4 stylesheet as shown
above in this README. The package stylesheet registers the built component
JavaScript so App Shell's grid, viewport, and overflow utilities are emitted in
the consuming app.

### Click-only Pathways sidebar

Opt into `sidebarBehavior="click"` on `SEIAppShell` (inherited by its Pathways
panel) or on a standalone `SEINavigationDrawerPanel` / `LibraryNavigationDrawerPanel`.
The default is open (`pinned`). The always-visible star reports `compact` when
minimized and `pinned` when expanded; pointer proximity, hover, and focus never
change its width. Compact controls expose name-only tooltips. Pass `sidebarMode`,
`defaultSidebarMode`, and `onSidebarModeChange` to control or remember the choice.
An `automatic` mode value is treated as `pinned` in click behavior.

```tsx
<SEIAppShell
  sidebarBehavior="click"
  defaultSidebarMode="pinned"
  sidebarWidth="14rem"
  sidebarCollapsedWidth="4.5rem"
  sidebar={<SEINavigationDrawerPanel variant="pathways" {...navigation} />}
>
  {page}
</SEIAppShell>
```

The shell pushes the page alongside the sidebar and animates both columns for
200ms (instant with reduced motion); labels reveal after expansion. The account
reserves the star's full footprint. The Library skin uses a round gold border.
Omit the behavior option to retain automatic pinning and legacy collapse APIs.
Mobile drawer configuration stays host-owned; keep its existing default variant.

### Shared overlay scrollbars (0.10.0)

All package scroll regions use one decorator: scroll areas, horizontal lanes,
virtual lists, App Shell main/sidebar, navigation, dialog/drawer/sheet bodies,
menus/popovers, command/combobox lists, tabs and toast stacks. It hides native
bars without a gutter and paints an aria-hidden overlay thumb inside the same
scroll element. It does not replace native wheel, touch, keyboard or focus
scrolling. App Shell's `mainRef` still points to the scrolling `<main>`.

```tsx
import { SEIOverlayScrollbar, useOverlayScrollbar } from "@seihouse/ui";

// New native scroll region:
<SEIOverlayScrollbar role="region" aria-label="Activity" className="max-h-64">
  {rows}
</SEIOverlayScrollbar>;

// Decorate an existing element; optional second argument forwards its ref:
const scrollRef = useOverlayScrollbar<HTMLElement>({ fades: false }, mainRef);
<main ref={scrollRef} className="overflow-y-auto">
  {page}
</main>;
```

For non-React integration, `attachOverlayScrollbar(element, { fades: true })`
returns a cleanup function. Attach only once per element. The decorator preserves
existing positioning and adds relative positioning to static scroll elements so
its decorative layer has a containing block. No additional scroll container is
created; labels, tabindex and children remain host-owned. The ref hook handles
mounting in portals and forwards ref cleanup as well as the original element.

Theme with `--sh-scrollbar-thumb`, `--sh-scrollbar-thumb-hover` (color or gradient),
`--sh-scrollbar-size` (6px), `--sh-scrollbar-size-hover` (10px), and
`--sh-scrollbar-inset` (3px). `--sh-scrollbar-glow` optionally supplies a hover
box-shadow. Thumbs show while scrolling and for one second afterward, or on hover
on devices with hover capability. They can be dragged without changing native
scroll behavior. ResizeObserver and a frame-batched mutation/scroll observer keep
both axes synchronized, including content that grows or shrinks.

Bounded surfaces use conditional edge masks; main pages have none. Reduced motion
removes the fade; forced colors restores system-native scrollbars. Custom thumbs
are decorative, never additional keyboard stops. The **Scroll Area → overlay**
Workbench preview and **Scroll/Overlay scrollbars** story demonstrate a page,
long list, horizontal lane, virtual list, dialog and menu.
