# @seihouse/ui

Reusable SEIHouse React components, interaction contracts, and design tokens.

Install the package and its required React peers:

```bash
npm install @seihouse/ui react react-dom
```

The package is ESM-only. Its `prepack` lifecycle builds JavaScript, declarations,
and CSS from source. Releases are published from the repository's manual GitHub
Actions workflow using npm trusted publishing.

```tsx
import { SEIButton } from "@seihouse/ui";
```

In the host Tailwind v4 stylesheet:

```css
@import "tailwindcss";
@import "@seihouse/ui/styles.css";
```

`styles.css` includes tokens and the Elemental Title stylesheet, and registers the
shipped JavaScript as a Tailwind source, including variant/focus/responsive classes. It does not include a second
Tailwind preflight. `@seihouse/ui/tokens.css` exports tokens alone for hosts that
manage class generation themselves. CSS files are marked as side effects.
Only the root JS API and these two CSS exports are supported; no private deep imports.
React 19 and the listed peers must resolve without `--legacy-peer-deps` or `--force`.

The workbench and Storybook intentionally alias the root API to source for HMR;
external consumers resolve only built files. Components are not copied into apps.

The experience contract is exactly `default`, `sea`, and `sen`. Set
`data-experience="sea" data-theme="dark"` on the document element for music
products, including portal-based overlays. `data-theme` independently selects
dark or light contrast. Use shared semantic tokens for colors, typography,
fields and glass treatments.

Version 0.3.0 narrows the public experience contract; consumers must select one
of these three values and use the shared tokens before upgrading.

## Versioning policy

`packages/seihouse-ui/package.json` is the source of the version published to npm
and used by consuming apps to identify the package copy. A change to runtime
behavior, public props or types, generated styles, or the package dependency
contract must bump this version in the same pull request. The pull request
workflow checks for a bump whenever publishable package files change, excluding
tests and documentation. Before `1.0.0`, use a patch for compatible fixes and a
minor version for new or breaking contracts. After `1.0.0`, use patch for
compatible fixes, minor for additive APIs, and major for breaking changes.

## Product presentation layers (0.4.0)

`SEIButton`, `SEIPanel`, `SEICard`, `SEIInput`, `SEITextarea`,
`SEIBottomNavigation` and `SEIDrawerContent` accept `unstyled` for a
product-owned skin. Existing styled defaults are unchanged. The caller supplies
focus styling when opting out of the default skin; native/keyboard/modal
behavior remains canonical. `SEICard.renderContent` replaces its convenience
slot composition. `SEIButton` additionally accepts `iconSize` and
`loadingIndicator`; bottom navigation accepts `showLabels` (default true).
These are generic extension points; the SEN layer in `packages/seihouse-library-ui`
composes them without creating a reverse dependency.

## Text

`ElementalTitle` is name lettering with an element: rank sets the color, the familiar
sets the element (fire, lightning, frost, celestial, void) and bond tier sets the
strength. Lightning runs on a choreography engine under a page-wide budget that keeps
crowded pages smooth, and official familiars add signatures that play on touch or when
the app asks. Its stylesheet is part of `styles.css`. See the
[component guide](src/text/elemental-title/README.md).

```tsx
import { ElementalTitle } from "@seihouse/ui";

<ElementalTitle as="h2" element="lightning" intensity="legendary" color={rankColor}>
  {readerName}
</ElementalTitle>;
```

## Header components — which one is which

Three components carry "header" in their name and they are not interchangeable.

| Component       | Role                                                                                 | Outline                              |
| --------------- | ------------------------------------------------------------------------------------ | ------------------------------------ |
| `SEIHeader`     | Heading block that opens a section of content: eyebrow, title, description, actions. | Renders a heading (`h2` by default). |
| `SEIPageHeader` | The same block at the top of a page, plus an optional breadcrumb.                    | Owns the page's `h1`.                |
| `SEIAppHeader`  | Persistent application chrome above both of them.                                    | Renders **no heading at all**.       |

`SEIAppHeader` is the top-level header of a focused SEIHouse application. It
stays put while the page underneath changes and answers three questions at
once: which app am I in, where am I inside it, and who am I signed in as. It
carries a branding slot, the app name, an optional contextual/page label, an
optional mobile navigation trigger, an actions slot, and a profile/account slot.

Because it is chrome rather than content, the app name is deliberately a
`<span>`: promoting it would place a competing top-level heading above every
page's own `SEIPageHeader`. Landmarks are explicit for the same reason —
`landmark="banner"` (the default) renders a real `<header>`, and
`landmark="none"` renders a plain `<div>` for hosts that already own the
`<header>`, `SEIAppShell`'s `header` slot being the usual case, so a page never
ends up with a header nested inside a header.

```tsx
<SEIAppShell
  header={
    <SEIAppHeader
      landmark="none"
      appName="SEA Console"
      branding={<SeaMark aria-hidden />}
      contextLabel="Vault"
      navigationTrigger={<MenuButton onClick={openDrawer} aria-expanded={open} />}
      actions={<SearchButton onClick={openSearch} />}
      profile={<AccountButton onClick={openAccount} />}
      onBrandSelect={() => router.push("/")}
    />
  }
>
  <SEIPageHeader title="Recovered fragments" />
</SEIAppShell>
```

Layout contract: the identity group is the flexible column and truncates first,
so a long app or context name shortens rather than pushing the account button
off a phone screen. The bar never reflows to a second row — a growing header
would shift the page beneath it — so hosts with more actions than fit a narrow
viewport collapse them into an overflow menu in the `actions` slot. The context
label stays in the accessibility tree at every width but is only painted from
`sm` up, and the navigation trigger retires at `md` unless
`navigationTriggerVisibility="always"`.

Routing, authentication, account logic, and navigation state stay outside. The
only control the component renders itself is the optional brand button, which
reports intent through `onBrandSelect`.

## App Shell integration

`SEIAppShell` owns the outer app layout: it renders one `<main>` landmark, keeps
the header and optional footer in place, and scrolls long main and sidebar
content inside the available height. Put the route view directly inside the
shell; do not add another `<main>` around it. Give `mainId` a page-unique value
and place a skip link before the shell so keyboard users can jump to that
region:

```tsx
import { useRef } from "react";
import { SEIAppHeader, SEIAppShell, SEIBottomNavigation } from "@seihouse/ui";

function AppLayout() {
  const mainRef = useRef<HTMLElement>(null);

  return (
    <>
      <a className="sr-only focus:not-sr-only" href="#app-main">
        Skip to main content
      </a>
      <SEIAppShell
        mainRef={mainRef}
        mainId="app-main"
        sidebarBreakpoint="lg"
        header={<SEIAppHeader landmark="none" appName="SEA Console" />}
        sidebar={<nav aria-label="Primary">{/* Host-owned links shown at lg+ */}</nav>}
        footerClassName="lg:hidden"
        footer={<SEIBottomNavigation aria-label="Primary" items={mobileDestinations} />}
      >
        <RouteView />
      </SEIAppShell>
    </>
  );
}
```

The shell fills `100dvh` by default and assumes a viewport-contained app with
internal scrolling. To place it inside a bounded host panel instead, give the
parent an explicit height and use `className="h-full min-h-0"` on the shell.
Keep the host's flex/grid ancestors shrinkable (`min-h-0`) as well. For a
document-scrolling page, use the page/layout primitives rather than this app
shell contract. `mainRef` points at the scrollable `<main>` element; the
component's forwarded `ref` continues to point at the outer shell `<div>`.

## File Upload and folder import

`SEIFileUpload` keeps the regular file picker and adds a separately named folder
picker when `allowDirectory` is set. It also recursively reads folders dropped
onto the drop area where the browser exposes directory entries. Folder files
pass through the same accept, size, count, and custom validation as regular
files. Directory selection enables multiple files and preserves browser-provided
`File.webkitRelativePath` values on the `File` objects sent to `onFilesChange`.
Files from a dropped folder carry the same `Folder/sub/file` relative paths,
restored from the dropped directory entries; loose dropped files keep an empty
path, as the regular file picker reports them.
Upload, storage, and folder processing remain host responsibilities.

```tsx
<SEIFileUpload
  allowDirectory
  accept="audio/*"
  maxFiles={250}
  onFilesChange={(files) => queueFiles(files)}
/>
```

The `sidebar` defaults to appearing at `md`; set `sidebarBreakpoint` to `"lg"`
or `"xl"` to delay it. The selected breakpoint controls both sidebar visibility
and the grid column, while the shell leaves responsive navigation to the host.
The host owns route state, the active item, and an alternate mobile drawer or
bottom navigation. If both desktop and mobile navigation are present, give each
landmark an accessible label and hide the inactive one at the same breakpoint.
The `header` slot is already wrapped in a `<header>`, so use
`SEIAppHeader landmark="none"` there.
The optional `footer` is a separate, non-scrolling row; keep its content short
and account for device safe areas with `SEISafeArea` or a navigation component
that already pads for the home indicator. Use `footerClassName` when the whole
row is breakpoint-specific, such as a mobile-only bottom navigation, so the
hidden footer does not leave an empty grid row or border at wider sizes.

Import `@seihouse/ui/styles.css` from the host's Tailwind v4 stylesheet as shown
above in this README. The package stylesheet registers the built component
JavaScript so App Shell's grid, viewport, and overflow utilities are emitted in
the consuming app.
