# Celestial Library UI

The UI monorepo owns the canonical Celestial Library presentation layer at
`@seihouse/library-ui`. Its panels, cards, controls, navigation, glyphs and particles
use the existing `sen` experience. Routing, authentication, storage, generation
and audio playback remain host responsibilities.

This phase provides a private **`@seihouse/library-ui@0.5.0`** artifact with two exports:

| Export                            | Built file                          | Purpose                                                                          |
| --------------------------------- | ----------------------------------- | -------------------------------------------------------------------------------- |
| `@seihouse/library-ui`            | `dist/ui/index.js` and `index.d.ts` | Components and their public types                                                |
| `@seihouse/library-ui/styles.css` | `dist/styles.css`                   | Shared UI tokens/source registration, SEN utility vocabulary, glass/spectral CSS |

The dependency direction is `@seihouse/library-ui` → `@seihouse/ui@^0.4.0 || ^0.5.0 || ^0.6.0`. The universal
package retains the existing `sen` experience and has no dependency on this
product package or its Library skin. The Library UI package has
no application imports. Its peer dependencies are React 19, React DOM 19, Lucide
and the universal UI package. Motion is an explicit runtime dependency for Celestial artwork.

The portable `@seihouse/sen` narrative engine and first-party `@seihouse/library` features remain owned by development. This repository produces no SEN artifact. Library may depend on SEN and Library UI; SEN must not depend on either Library package.

## Consume the built artifact

Build with `pnpm build:package`, then pack both packages, in dependency order:

```sh
npm pack ./packages/seihouse-ui --pack-destination ./output
npm pack ./packages/seihouse-library-ui --pack-destination ./output
```

Install both tarballs in a host with the declared peers. The application uses
Tailwind CSS v4, matching the universal UI stylesheet contract. Import CSS once:

```css
@import "tailwindcss";
@import "@seihouse/library-ui/styles.css";
```

```tsx
import { LibraryPanel, LibraryTextBox, ManifestButton } from "@seihouse/library-ui";

export function WorldForm() {
  return (
    <section data-experience="sen" data-theme="dark">
      <LibraryPanel>
        <LibraryTextBox label="World name" defaultValue="Astral realm" />
        <ManifestButton type="submit">Manifest World Blueprint</ManifestButton>
      </LibraryPanel>
    </section>
  );
}
```

CSS is explicitly imported rather than evaluated by the JavaScript entry, so
Node SSR and native ESM can load the package. The CSS registers shipped JS with
Tailwind; no workspace source alias or host `node_modules` scan is needed.
Importing this CSS alone without a Tailwind v4 build does not generate utilities.

Font families retain the reference: Rubik, Noto Serif, Alegreya and Alegreya SC.
The host supplies these fonts under its font-loading policy; serif/system
fallbacks remain available. The package performs no remote font requests.
SEN utility colors and font names are prefixed `sen-` to avoid overriding the
universal or host Tailwind theme. Existing `--library-card-*`,
`--celestial-accent` and spectral/glass class hooks are retained.

## Public components

- `LibraryPanel`: `default`, `callout`, `footer`; polymorphic section container.
- `LibraryCard`: static, button or link cards; `default` and `callout` skins,
  accent colors, padding and convenience slots. Compound exports:
  `LibraryCardMedia`, `LibraryCardContent`, `LibraryCardHeader`, `LibraryCardTitle`,
  `LibraryCardDescription`, `LibraryCardBody`, `LibraryCardMetadata`,
  `LibraryCardActions`, `LibraryCardFooter`.
- `LibraryButton`: `primary`, `secondary`, `ghost`, `danger`; `sm`, `md`, `lg`,
  `icon`; refs, icon slots, `iconSize`, custom loading indicator and native props.
- `ManifestButton`: spectral creation action with the same behavior and sizing.
- `LibraryTextBox`, `LibraryTextArea`: glass fields, labels/helper/error IDs,
  controlled string callbacks, uncontrolled native values, icons, overlays,
  compact mode, required/disabled state and textarea character count.
- `LibraryHeaderBadge`: title, subtitle, optional emblem and home link; use
  `mode="app-header"` for inline, non-heading composition inside `SEIAppHeader`.
- `LibraryNavigationDrawer`, `LibraryNavigationDrawerPanel`: controlled modal
  and standalone sidebar, grouped destinations, profile and close labels.
- `LibraryBottomNavigation`: presentational destinations, selection callbacks,
  optional visually hidden labels, safe-area dock.
- `LibraryDragonCycleIcon`, `LibrarySoundGlyph`: specialized cycle and sound
  vocabulary, decorative/informative accessibility contracts.
- `ParticleEffect`: accent-derived celestial particles with embedded glyphs,
  foreground calm zones, speed and dispersion controls; no host asset URLs.

All reference public `Library*`, `ManifestButton` and `ParticleEffect` prop types
are exported with their existing names. Raw shared primitives and `cn` come from
`@seihouse/ui`; they are not duplicated or re-exported by Library UI.

## Independent verification

`/sen` in the workbench shows the complete set. Each of the 12 families has its
own catalog entry and Storybook story under `Library UI`. Both preview apps
resolve Library UI's built exports. Run `pnpm build:package` again after changing Library UI
source before using an already running preview server.

```sh
pnpm typecheck
pnpm test:unit
pnpm test:package
pnpm lint
pnpm build
pnpm build:storybook
pnpm exec playwright test test/accessibility/sen-library.spec.ts
```

The package contract installs fresh tarballs outside the workspace, verifies
runtime exports, TypeScript contracts, reproducibility, and compiles the shipped
CSS with Tailwind. Browser checks cover desktop/mobile layout, fields, keyboard
activation, modal focus/dismissal, axe accessibility and changing motion settings.
See [the Prompt 3 migration map](../../docs/library-ui-migration.md) for import mapping
and intentional differences.

## Elemental title (moved)

`LibraryElementalTitle` moved to the universal package as `ElementalTitle`
(`import { ElementalTitle } from "@seihouse/ui"`), in its own **Text** section, because
every SEIHouse surface can use it. Its styles ship with `@seihouse/ui/styles.css`, which
this package's stylesheet already imports. See
[`packages/seihouse-ui/src/text/elemental-title/README.md`](../seihouse-ui/src/text/elemental-title/README.md)
and the migration row in [the migration map](../../docs/library-ui-migration.md).

## LibraryScrubber

Transferred from development's chapter manifestation journey on 2026-09-10. The UI package owns this reusable presentation, including all SVG character and gate artwork; no remote assets or generation services are required. Motion is a packaged runtime dependency.

```tsx
import { LibraryScrubber } from "@seihouse/library-ui";

<LibraryScrubber
  progress={0.69}
  travelerId="cultivator"
  trailStyle="qi-glow"
  destinationId="sect"
  status={{ title: "Chapter 1", state: "Manifesting" }}
/>;
```

Progress is caller-controlled, normalized 0–1; null or non-finite values show unknown progress. This is a progress indicator, not an interactive seek slider. Characters: cultivator, sword-rider, spirit-beast. Trails: qi-glow, starlight-trail, scroll-trail. Destinations: door (gate), sect (temple), cave. Omitted destinations follow the character's recommendation; unknown ids use safe defaults. Optional accent, accentSoft, destinationAccent, status, className and aria-label props support other contexts. Layout needs no Tailwind scanning. Reduced motion freezes unknown-progress drift as well as character and gate animation.

Development adopts this artifact directly; no second scrubber implementation or JourneyScrubber compatibility export remains in its product graph.

## Ownership reconstruction (2026-09-18)

Coordinated with Development PR #227. Version 0.5.0 adds three stateless families:

- `LibraryIcon` and the named `Library*Icon` renderers: 28 embedded Celestial glyphs, with no remote asset requirement or routing logic. Decorative by default; pass `role="img"`, `aria-hidden={false}` and an accessible label for informative use.
- `LibraryCaveBackdrop`: caller-selected image, decorative atmosphere, optional ambient particles. Library owns environment selection, account settings and persistence.
- Manifestation artwork: `ManifestationChamber`, `ChamberForegroundMotes`, `CelestialChannel`, `SwordCultivatorClash`, and `CelestialScrollVessel`. The vessel receives only visual phase, image and placeholder label. It never advances a reveal, creates content or authorizes an operation. SEN owns the general reveal contract; Library adapts it to this visual surface.

The existing scrubber also exports its visual registries and prop types for composition. None of these entries imports SEN, Library behavior, Workshop state, accounts, catalogs, backend services or providers. Historical `data-sen-*` icon selectors are visual CSS/inspection hooks, not a dependency on the narrative engine.

The source artwork was transferred from Development's approved implementation. The original approved baseline was Development `60934256df3e84c5dbb50c917a03b18b038399d2`; ownership work continued on PR #227. Imported artwork is now maintained here. No business rules or production infrastructure were transferred.
