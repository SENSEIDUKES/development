import { createElement as h } from 'react';
import { createRoot } from 'react-dom/client';
import { NovelExpandedLogo } from '../index.js';
import '../styles.css';

const sizes = [24, 32, 40, 56, 80, 128, 256];
const sizeFigure = (size, theme) => h('figure', { key: size },
  h(NovelExpandedLogo, { size, theme, 'data-size': size }),
  h('figcaption', null, `${size}px`));
createRoot(document.getElementById('root')).render(h('div', null,
  ...['dark', 'light'].map(theme => h('section', { className: theme, key: theme, 'aria-label': `${theme} sizes` },
    ...sizes.map(size => sizeFigure(size, theme)))),
  h('section', { 'aria-label': 'Composition checks' },
    h('figure', null, h(NovelExpandedLogo, { animated: false, 'data-test': 'static' }), h('figcaption', null, 'Static')),
    h('figure', null, h(NovelExpandedLogo, { className: 'responsive-logo', imageSizes: '(max-width: 1000px) 10vw, 96px', 'data-test': 'responsive' }), h('figcaption', null, 'Responsive')),
    h('a', { href: '#root', 'aria-label': 'Novel Expanded home' }, h(NovelExpandedLogo, { alt: '' }))),
));
