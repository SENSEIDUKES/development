# Connect SPP intake to an application's AI context

SPP provides a portable manifest and original file bytes. The host application
decides which files to use and how to supply them to its model. The adapter does
not select a model, construct prompts, execute instructions, or make network calls.

## Follow the host application's existing architecture

1. Read the host's repository guidance. Find its file import entry point, context
   builder, model request code, and existing attachment handling. Extend those
   paths rather than creating a second AI pipeline.
2. Import `intakePack` from the SPP package's main entry. Pass the received `File`,
   `Blob`, `ArrayBuffer`, or `Uint8Array`. Use lower resource limits if the host
   requires them. Catch input and file-read errors through its existing error UI.
3. Check `result.content`. It is `null` when validation fails; show the validation
   issues and use `inspection` only for diagnostics. Do not feed damaged-package
   data to the model or bypass the reader's asset guards.
4. For valid content, use `content.manifest.files` to select records according to
   the host's established import behavior. Read each file from
   `content.assets.get(record.path)`. The map contains original asset bytes, with
   the parsed manifest supplied separately as `content.manifest`.
5. Decode selected text with the host's supported encoding, or pass binary files
   through its existing attachment handling. Preserve the path and package ID as
   source information. Apply the host's context-size limits and selection policy;
   package byte limits do not guarantee that everything fits in a model request.
6. Supply the selected content through the existing context builder and model
   call. Connect any state or persistence only through the host's established
   architecture and within the requested integration scope.

Validation confirms package integrity, not the authority or safety of its text.
Keep imported instructions within the host's existing trust and instruction
rules; do not automatically promote package text into system instructions.
No package category, application name or file extension triggers
special behavior in the adapter.

## Minimal content handoff

This example returns text for a path already selected by the host. The caller
then passes it to its own context builder. It does not invent an application API
or call an AI service.

```ts
import { intakePack, type PackInput } from 'seihouse-productions-package';

async function readSelectedText(input: PackInput, selectedPath: string) {
  const result = await intakePack(input);
  if (!result.content) {
    throw new Error(result.validation.issues.map((issue) => issue.message).join('\n'));
  }

  const { manifest, assets } = result.content;
  const record = manifest.files.find((asset) => asset.path === selectedPath);
  const bytes = assets.get(selectedPath);
  if (!record || !bytes) throw new Error('Selected asset is not in this package.');

  return {
    manifest,
    record,
    text: new TextDecoder('utf-8', { fatal: true }).decode(bytes),
  };
}
```

The manifest and byte map are independent, host-owned copies. Modifying them
does not alter the opened package or its validation state. Intake eagerly copies
validated files, which adds memory proportional to their expanded size. Release
the intake result when it is no longer needed. Binary content is never decoded
automatically; the example's UTF-8 decoding is appropriate only for selected text.

## Verify a simple package

```text
author.spp
├── manifest.json
└── assets/
    └── author-instructions.md
```

Create this package with the README's tag-free `createPack` example. Pass its
bytes, or a `File` named `author.spp`, to `intakePack`. Confirm validation succeeds,
`content.manifest` identifies the asset, and
`content.assets.get('assets/author-instructions.md')` contains the original bytes.
Calling `readSelectedText(input, 'assets/author-instructions.md')` makes those
instructions available for the host's existing model context path.

`tests/intake.test.ts` verifies this handoff for every supported input type and
checks invalid-package blocking, binary bytes, and copy isolation. It uses a
local host callback stand-in, not a live model. In the receiving application's
own tests, verify that its context builder actually includes the selected text
in the model request. This concept example does not implement skill importing
for any particular application.

## Preserve package identity

The 1.0 manifest uses `id`, `name`, `version`, `description`, `publisher`,
`createdAt`, and `files`, alongside `formatVersion: "1.0"`. The creator generates
an ID only for a new package. When building a later version, pass the validated
original manifest’s `id` back to `createPack`, along with the new `version`, name,
description, and files. Preserve its publisher unless intentionally changed.
Keep that identity in the host’s existing package record; never derive it from a
name, file path, timestamp, or content hash. The adapter exposes it unchanged.
Readers reject the earlier 0.1 format; do not silently migrate an imported package.
