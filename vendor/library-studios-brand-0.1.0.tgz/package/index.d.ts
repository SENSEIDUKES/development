import type { CSSProperties, HTMLAttributes, ReactElement, Ref } from 'react';

export interface NovelExpandedLogoProps extends Omit<HTMLAttributes<HTMLSpanElement>, 'children'> {
  /** Plate height in CSS pixels, or 32 / 40 / 56 / 80px presets. Default: 40px. */
  size?: number | 'sm' | 'md' | 'lg' | 'xl';
  theme?: 'light' | 'dark';
  /** Reduced-motion preferences always disable animation. */
  animated?: boolean;
  /** Use an empty string inside a link that already has an accessible name. */
  alt?: string;
  /** Image display width for hosts that resize the plate with CSS. */
  imageSizes?: string;
  ref?: Ref<HTMLSpanElement>;
  style?: CSSProperties & { '--ne-logo-height'?: string };
}

export declare function NovelExpandedLogo(props?: NovelExpandedLogoProps): ReactElement;
