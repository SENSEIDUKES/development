# @seihouse/ui

Private, versioned ESM distribution. No registry publication is required.

From the repository root, run `pnpm install --frozen-lockfile`, then
`npm pack ./packages/seihouse-ui --pack-destination <artifact-directory>`.
`prepack` builds JavaScript and declarations from source. Commit the resulting
versioned tarball in the consumer and install it with npm using a `file:`
dependency; commit the generated lockfile (including its SHA-512 integrity).
Record the UI source commit alongside the artifact. Rebuild twice to check
byte-for-byte reproducibility. Keep Node/npm versions fixed when regenerating.

```tsx
import { SEIButton } from "@seihouse/ui";
```

In the host Tailwind v4 stylesheet:

```css
@import "tailwindcss";
@import "@seihouse/ui/styles.css";
```

`styles.css` includes tokens and registers the shipped JavaScript as a Tailwind
source, including variant/focus/responsive classes. It does not include a second
Tailwind preflight. `@seihouse/ui/tokens.css` exports tokens alone for hosts that
manage class generation themselves. CSS files are marked as side effects.
Only the root JS API and these two CSS exports are supported; no private deep imports.
React 19 and the listed peers must resolve without `--legacy-peer-deps` or `--force`.

The workbench and Storybook intentionally alias the root API to source for HMR;
external consumers resolve only built files. Components are not copied into apps.

The experience contract is exactly `default`, `sea`, and `sen`. Set
`data-experience="sea" data-theme="dark"` on the document element for music
products, including portal-based overlays. `data-theme` independently selects
dark or light contrast. Use shared semantic tokens for colors, typography,
fields and glass treatments.

Version 0.3.0 narrows the public experience contract; consumers must select one
of these three values and use the shared tokens before upgrading.

## Product presentation layers (0.4.0)

`SEIButton`, `SEIPanel`, `SEICard`, `SEIInput`, `SEITextarea`,
`SEIBottomNavigation` and `SEIDrawerContent` accept `unstyled` for a
product-owned skin. Existing styled defaults are unchanged. The caller supplies
focus styling when opting out of the default skin; native/keyboard/modal
behavior remains canonical. `SEICard.renderContent` replaces its convenience
slot composition. `SEIButton` additionally accepts `iconSize` and
`loadingIndicator`; bottom navigation accepts `showLabels` (default true).
These are generic extension points; the SEN layer in `packages/seihouse-library-ui`
composes them without creating a reverse dependency.

## Header components — which one is which

Three components carry "header" in their name and they are not interchangeable.

| Component       | Role                                                                                 | Outline                              |
| --------------- | ------------------------------------------------------------------------------------ | ------------------------------------ |
| `SEIHeader`     | Heading block that opens a section of content: eyebrow, title, description, actions. | Renders a heading (`h2` by default). |
| `SEIPageHeader` | The same block at the top of a page, plus an optional breadcrumb.                    | Owns the page's `h1`.                |
| `SEIAppHeader`  | Persistent application chrome above both of them.                                    | Renders **no heading at all**.       |

`SEIAppHeader` is the top-level header of a focused SEIHouse application. It
stays put while the page underneath changes and answers three questions at
once: which app am I in, where am I inside it, and who am I signed in as. It
carries a branding slot, the app name, an optional contextual/page label, an
optional mobile navigation trigger, an actions slot, and a profile/account slot.

Because it is chrome rather than content, the app name is deliberately a
`<span>`: promoting it would place a competing top-level heading above every
page's own `SEIPageHeader`. Landmarks are explicit for the same reason —
`landmark="banner"` (the default) renders a real `<header>`, and
`landmark="none"` renders a plain `<div>` for hosts that already own the
`<header>`, `SEIAppShell`'s `header` slot being the usual case, so a page never
ends up with a header nested inside a header.

```tsx
<SEIAppShell
  header={
    <SEIAppHeader
      landmark="none"
      appName="SEA Console"
      branding={<SeaMark aria-hidden />}
      contextLabel="Vault"
      navigationTrigger={<MenuButton onClick={openDrawer} aria-expanded={open} />}
      actions={<SearchButton onClick={openSearch} />}
      profile={<AccountButton onClick={openAccount} />}
      onBrandSelect={() => router.push("/")}
    />
  }
>
  <SEIPageHeader title="Recovered fragments" />
</SEIAppShell>
```

Layout contract: the identity group is the flexible column and truncates first,
so a long app or context name shortens rather than pushing the account button
off a phone screen. The bar never reflows to a second row — a growing header
would shift the page beneath it — so hosts with more actions than fit a narrow
viewport collapse them into an overflow menu in the `actions` slot. The context
label stays in the accessibility tree at every width but is only painted from
`sm` up, and the navigation trigger retires at `md` unless
`navigationTriggerVisibility="always"`.

Routing, authentication, account logic, and navigation state stay outside. The
only control the component renders itself is the optional brand button, which
reports intent through `onBrandSelect`.
